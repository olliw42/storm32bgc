/*
  (c) www.olliw.eu, OlliW, OlliW42
   
  License: GPL v3

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
   
  For the GNU General Public License see <http://www.gnu.org/licenses/>.
*/

/* MKR100 secrets:
- that's no joke, it happens: https://forum.arduino.cc/index.php?topic=434802.0
*/


#include "gopro/owGoProClass.h"


class owGoPro: public owGoProClass  //if desired also the owGoProAdvancedClass can be inherited here
{
  public:
    owGoPro(const String ssid, const String password, bool debug = true);

    void begin(void);
    void end(void);
    bool isConnected(void);  //  return -(WiFi.status());
    bool getMac(void);
    void printCredentials(void);
    void printMac(const uint8_t mac[]);
    void startupCmds(void);
    
    void loop(void){ loop(millis()); };
    void loop(unsigned long curtime_ms);
    
    void sendWoL(void);
    bool connectClient(void);
    int16_t getMacfromInfo(void);

    int16_t sendCmdviaHttp(const String& request); //overwrite

    void enableDebug(Serial_* debug_port){};
    bool shoot(void);
    bool stopShoot(void);

    int16_t getMode(void){ return _mode; }
    void setMode(int16_t mode){ _mode = mode; }

  private:
    WiFiClient _wifiClient;
    WiFiUDP _udpClient;
    String _ssid;
    String _password;
    
    uint8_t _mac[MAC_ADDRESS_LENGTH];
    bool _mac_isvalid;

    bool _debug;

    unsigned long _heartbeat_next_ms;

    //this keeps the last HTTP request
    String _request; 
    String _response;
    uint16_t _response_code;

    //this keeps some gorpo status infos
    int16_t _mode;
    int16_t _submode;
};


owGoPro::owGoPro(const String ssid, const String password, bool debug)
{
    _ssid = ssid;
    _password = password;
    _debug = debug;
    _mac_isvalid = false;
}


void owGoPro::begin(void)
{
    _mode = -1;
    _submode = -1;
    
    _heartbeat_next_ms = millis() + GOPRO_LOOP_MS;
  
#if defined(ARDUINO_ARCH_ESP8266) // ESP8266
    WiFi.setOutputPower(0.0f); //0 dBm //not available with MKR1000
    WiFi.persistent(false);
    WiFi.mode(WIFI_STA); //this is needed for me
#endif    
    
    WiFi.begin(_ssid.c_str(), _password.c_str());

    //while (WiFi.status() != WL_CONNECTED) {
    //  delay(100);
    //  Serial.print(".");
    //}

    //somehow, the MKR1000 won't connect without that line!!!
    if (WiFi.status() == WL_CONNECTED) {
      return;
    }
}


void owGoPro::end(void)
{
    _wifiClient.stop();
    _udpClient.stop();
    WiFi.disconnect();
}


bool owGoPro::isConnected(void)
{
  return (WiFi.status() == WL_CONNECTED);
}


void owGoPro::startupCmds(void)
{
//    if (isConnected()) sendCmd(GOPRO_CMD_SUBMODE_VIDEO);
//    if (isConnected()) sendCmd(GOPRO_CMD_SHUTTER_OFF);
    if (!isConnected()) return;

    getMac();
    sendCmd(GOPRO_CMD_SUBMODE_VIDEO);
    sendCmd(GOPRO_CMD_SHUTTER_OFF);
}


void owGoPro::loop(unsigned long curtime_ms)
{
  if( curtime_ms > _heartbeat_next_ms ){ 
    _heartbeat_next_ms += GOPRO_LOOP_MS;
    if (WiFi.status() == WL_CONNECTED){
      GOPRO_DBG("*");
    }else{
      GOPRO_DBG("!");
      begin(); //this also seems to work quite well! Somehow can't put this with the next into a method!?!?!
      startupCmds();
    }
  }
}


bool owGoPro::connectClient(void)
{
    if (!isConnected()) return false;
    
    if (_wifiClient.connect(GOPRO_HOST, GOPRO_WIFI_PORT)) {
        return true;
    }
    
    return false;
}


void owGoPro::sendWoL(void)
{
    if (!_mac_isvalid) {
      GOPRO_DBG("gopro MAC is not valid");
      return;
    }

    GOPRO_DBG("gopro send WoL");
  
    uint8_t preamble[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
    IPAddress addr(255, 255, 255, 255);

    _udpClient.begin(GOPRO_UDP_PORT);
    _udpClient.beginPacket(addr, GOPRO_UDP_PORT);
    _udpClient.write(preamble, 6);
    for (uint8_t i = 0; i < 16; i++) _udpClient.write(_mac, MAC_ADDRESS_LENGTH);
    _udpClient.endPacket();
    _udpClient.stop();
}


int16_t owGoPro::sendCmdviaHttp(const String& request)
{
    if (!connectClient()){
      GOPRO_DBG("gopro connection failed");
      return false;
    }

    GOPRO_DBG("gopro connection successful");

    //send the request per GET
    _request = String("GET ") + request + " HTTP/1.1\r\n" +
               "Host: " + GOPRO_HOST + "\r\n" +
//               "Connection: close\r\n\r\n";
               "Connection: Keep-Alive\r\n\r\n";
    _wifiClient.print(_request);
    
    //read the response
    _response = "";

    uint32_t curtime_ms = millis();
    while ((_wifiClient.available() == 0) && (curtime_ms + GOPRO_RESPONSE_TIMEOUT_MS > millis())) {
        delay(5);
    }

    if (_wifiClient.available() <= 0) {
      GOPRO_DBG("gopro reading response failed");
      return false;
    }
    
    while (_wifiClient.available() > 0) {
        char c = _wifiClient.read();
        _response += c;
    }

    GOPRO_DBG(_response);

    //extract the response code
    int blank_pos = _response.indexOf(" ");
    String str = _response.substring(blank_pos+1);
    _response_code = atoi(str.c_str());

    GOPRO_DBG(_response_code);

    _wifiClient.stop();

    if (_response_code == 200) return true;
    return -(_response_code);
}


void owGoPro::printCredentials(void)
{
    if (!_debug) return;

    GOPRO_DBG("");
    GOPRO_DBG(String("SSID: ") + WiFi.SSID());
    GOPRO_DBG(String("Password: ") + _password);
    GOPRO_DBG(String("IP Address: ") + WiFi.localIP());
    GOPRO_DBG(String("RSSI: ") + WiFi.RSSI() + " dBm");
    uint8_t bmac[MAC_ADDRESS_LENGTH];
    WiFi.macAddress(bmac);
    GOPRO_DBG("WifiBoard MAC:"); printMac(bmac);
    GOPRO_DBG("GoPro MAC:"); if(_mac_isvalid){ printMac(_mac); }else{ GOPRO_DBG("no valid mac"); }
}


void owGoPro::printMac(const uint8_t mac[])
{
    if (!_debug) return;

    uint8_t c;
    char mac_str[20];
    uint8_t pos = 0;
    for (uint8_t i = 0; i < MAC_ADDRESS_LENGTH; i++) {
        c = (mac[i] & 0xF0) >> 4;
        mac_str[pos++] = ( c <= 9 ) ? '0'+c : 'a'+c-10;
        c = (mac[i] & 0x0F);
        mac_str[pos++] = ( c <= 9 ) ? '0'+c : 'a'+c-10;
        if (i < MAC_ADDRESS_LENGTH-1) mac_str[pos++] = ':';
    }
    mac_str[pos++] = '\0';
    GOPRO_DBG(mac_str);
}


bool owGoPro::getMac(void)
{
#if defined(ARDUINO_ARCH_ESP8266) // ESP8266
    return false;
#else
    GOPRO_DBG("gopro get MAC");
    
/*    if (_mac_isvalid) {
      printMac(_mac);
      return true;
    } */

    bool isreverted = false;
#if defined(ARDUINO_ARCH_ESP32)
    _mac = WiFi.BSSID();
#else
    WiFi.BSSID(_mac);
    isreverted = true;
#endif

    if (isreverted) {
      for (uint8_t i = 0; i < MAC_ADDRESS_LENGTH / 2; i++) {
        uint8_t m = _mac[i];
        _mac[i] = _mac[MAC_ADDRESS_LENGTH - i - 1];
        _mac[MAC_ADDRESS_LENGTH - i - 1] = m;
      }
    }

    printMac(_mac);
    _mac_isvalid = true;
    return true;
#endif
}


int16_t owGoPro::getMacfromInfo(void)
{
    GOPRO_DBG("gopro get MAC from info");

/*    if (_mac_isvalid) {
      printMac(_mac);
      return true;
    } */

    int16_t res = sendCmdviaHttp("/gp/gpControl/info");
    if (res != true) return res;

    //find ap_mac entry in response
    int ap_mac_pos = _response.indexOf("ap_mac");
    int mac_start = _response.indexOf(":", ap_mac_pos+1);
    int mac_end = _response.indexOf(",", mac_start+1);
        
    String mac_string = _response.substring(mac_start+2, mac_end-1);
        
    if (mac_string.length() != 2*MAC_ADDRESS_LENGTH) {
        GOPRO_DBG("SHIT");
        return -4242; //return with something hopefully bad
    }
        
    uint8_t mac[MAC_ADDRESS_LENGTH];
    char c;
    for (uint8_t i = 0; i < MAC_ADDRESS_LENGTH; i++) {
        //we could do here some more checks like that each char is in [0..9a..f], or all are lower case, or length is ok, etc. pp
        c = mac_string.charAt(2*i);
        mac[i] = (( c <= '9' ) ? c - '0' : c - 'a' + 10) * 16;
        c = mac_string.charAt(2*i+1);
        mac[i] += ( c <= '9' ) ? c - '0' : c - 'a' + 10;
    }

    memcpy(_mac, mac, MAC_ADDRESS_LENGTH);
    _mac_isvalid = true;

    printMac(mac);
    
    return true;
}



bool owGoPro::shoot()
{
    return cmdShutterOn();
}

bool owGoPro::stopShoot()
{
    return cmdShutterOff();
}

