'use strict';

/*TODO:
- always do a read before a write ?
- check validity after a write


*/

//http://geekswithblogs.net/lorint/archive/2006/03/07/71625.aspx
//https://stackoverflow.com/questions/1018705/how-to-detect-timeout-on-an-ajax-xmlhttprequest-call-in-the-browser
function ajaxDo(type, url, content, func) {

    if( XhttpTransferInProgress ){ alert("A Xhttp transfer is currently in progress. Wait and repeat."); return; }
    XhttpTransferInProgress = true;
    
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if( this.readyState == 4 ){ 
            clearTimeout(xhttpTimeout); 
            if( (this.readyState == 4) && (this.status == 200) ){ 
                ConnectionIsValid = true; 
                func(this); 
            }else{
                ConnectionIsValid = false;
                setPAllToInvalid();                
            }
        }
    };
    xhttp.open(type, url, true); //xhttp.open('POST', url, true); //xhttp.open('GET', url, true);
    if( content.length ) xhttp.send(content); else xhttp.send();
    // timeout to abort in 5 seconds
    function ajaxTimeout(){
        xhttp.abort();
        ConnectionIsValid = false;
        setPAllToInvalid();
        alert("Xhttp request timed out");
    }    
    var xhttpTimeout = setTimeout(ajaxTimeout,3000);
    
    XhttpTransferInProgress = false;
}


function ajaxPost(url, content, func) {
    ajaxDo('POST', url, content, func);
}

function ajaxGet(url, content, func) {
    ajaxDo('GET', url, content, func);
}


//-----------------------------------------------------
// parameter description
//-----------------------------------------------------

//capability constants
var BOARD_CAPABILITY_FOC           =  0x0100;

var FocIsEnabled = false;

//this is a flag to avoid that more than one xhhtp transfer is going on at a time
// is this really working????
var XhttpTransferInProgress = false;

//this is flag tells about the connection to the ESP and/or STorM32
// it holds the success result of the last XhttpRequest, as well as that of the returned resposne, if it was 'o' or not
var ConnectionIsValid = false;

//this is flag tells if teh ESP is in AP+Gopro Station mode
var GoproIsAvailable = false;

//this is the string of hex received via read, i.e. g
// it is needed to keep the scripts, and to keep values not available or changed
// it has to be maintained
var PValues = '';

//this is to maintain the status of the PValues
var INVALID = 0;
var VALID = 1;
var MODIFIED = 2;
var PStatus = INVALID;  //this can be invalid = 0, valid = 1, modified; 

var P =
{
/*
  'FirmwareVersion' : {'default' : '', 'column' : 1, 'unit' : '', 'size' : 16, 'hidden' : 0, 
                       'page' : 'dashboard', 'type' : 'STR+READONLY', 'name' : 'Firmware Version'},
  'GyroLPF' : {'steps' : 1, 'default' : 1, 'adr' : 12, 'max' : 6, 'len' : 0, 
               'page' : 'pid', 'min' : 0, 
               'choices' : ['off', '1.5 ms', '3.0 ms', '4.5 ms', '6.0 ms', '7.5 ms', '9 ms'], 
               'type' : 'LIST', 'unit' : '', 'size' : 1, 'hidden' : 0, 'pos' : [1, 1], 
               'name' : 'Gyro LPF', 'ppos' : 0},
  'PitchP' : {'steps' : 10, 'default' : 400, 'adr' : 0, 'max' : 3000, 
              'page' : 'pid', 'min' : 0, 'len' : 5, 'size' : 2, 'ppos' : 2, 
              'type' : 'UINT', 'hidden' : 0, 'pos' : [2, 1], 
              'name' : 'Pitch P', 'unit' : ''},
*/              
  'FirmwareVersion' : {'steps' : 1, 'page' : 'dashboard', 'name' : 'Firmware Version', 'default' : '', 'size' : 16, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'STR+READONLY', 'column' : 1},
  'Board' : {'steps' : 1, 'page' : 'dashboard', 'name' : 'Board', 'default' : '', 'size' : 16, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'STR+READONLY'},
  'Name' : {'steps' : 1, 'page' : 'dashboard', 'name' : 'Name', 'default' : '', 'size' : 16, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'STR+READONLY'},
  'GyroLPF' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'pid', 'max' : 6, 'choices' : ['off', '1.5 ms', '3.0 ms', '4.5 ms', '6.0 ms', '7.5 ms', '9 ms'], 'size' : 1, 'adr' : 12, 'pos' : [1, 1], 'min' : 0, 'name' : 'Gyro LPF', 'default' : 1, 'foc' : 1, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'FocGyroLPF' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'pid', 'max' : 6, 'choices' : ['off', '1.5 ms', '3.0 ms', '4.5 ms', '6.0 ms', '7.5 ms', '9 ms'], 'size' : 1, 'adr' : 41, 'pos' : [1, 1], 'min' : 0, 'name' : 'Foc Gyro LPF', 'default' : 1, 'foc' : 2, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'Imu2FeedForwardLPF' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'pid', 'max' : 6, 'choices' : ['off', '1.5 ms', '4 ms', '10 ms', '22 ms', '46 ms', '94 ms'], 'size' : 1, 'adr' : 72, 'min' : 0, 'name' : 'Imu2 FeedForward LPF', 'default' : 1, 'foc' : 3, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'VoltageCorrection' : {'len' : 7, 'steps' : 1, 'ppos' : 0, 'page' : 'pid', 'max' : 200, 'size' : 2, 'adr' : 75, 'pos' : [1, 4], 'min' : 0, 'name' : 'Voltage Correction', 'default' : 0, 'foc' : 3, 'unit' : '%', 'type' : 'UINT', 'hidden' : 0},
  'RollYawPDMixing' : {'len' : 5, 'steps' : 1, 'ppos' : 0, 'page' : 'pid', 'max' : 100, 'size' : 2, 'adr' : 73, 'min' : 0, 'name' : 'Roll Yaw PD Mixing', 'default' : 0, 'foc' : 0, 'unit' : '%', 'type' : 'UINT', 'hidden' : 0},
  'PitchP' : {'len' : 5, 'steps' : 10, 'ppos' : 2, 'page' : 'pid', 'max' : 3000, 'size' : 2, 'adr' : 0, 'pos' : [2, 1], 'min' : 0, 'name' : 'Pitch P', 'default' : 400, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'PitchI' : {'len' : 7, 'steps' : 50, 'ppos' : 1, 'page' : 'pid', 'max' : 32000, 'size' : 2, 'adr' : 1, 'min' : 0, 'name' : 'Pitch I', 'default' : 1000, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'PitchD' : {'len' : 3, 'steps' : 50, 'ppos' : 4, 'page' : 'pid', 'max' : 8000, 'size' : 2, 'adr' : 2, 'min' : 0, 'name' : 'Pitch D', 'default' : 500, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'PitchMotorVmax' : {'len' : 5, 'steps' : 1, 'ppos' : 0, 'page' : 'pid', 'max' : 255, 'size' : 2, 'adr' : 3, 'min' : 0, 'name' : 'Pitch Motor Vmax', 'default' : 150, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'RollP' : {'len' : 5, 'steps' : 10, 'ppos' : 2, 'page' : 'pid', 'max' : 3000, 'size' : 2, 'adr' : 4, 'pos' : [3, 1], 'min' : 0, 'name' : 'Roll P', 'default' : 400, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'RollI' : {'len' : 7, 'steps' : 50, 'ppos' : 1, 'page' : 'pid', 'max' : 32000, 'size' : 2, 'adr' : 5, 'min' : 0, 'name' : 'Roll I', 'default' : 1000, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'RollD' : {'len' : 3, 'steps' : 50, 'ppos' : 4, 'page' : 'pid', 'max' : 8000, 'size' : 2, 'adr' : 6, 'min' : 0, 'name' : 'Roll D', 'default' : 500, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'RollMotorVmax' : {'len' : 5, 'steps' : 1, 'ppos' : 0, 'page' : 'pid', 'max' : 255, 'size' : 2, 'adr' : 7, 'min' : 0, 'name' : 'Roll Motor Vmax', 'default' : 150, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'YawP' : {'len' : 5, 'steps' : 10, 'ppos' : 2, 'page' : 'pid', 'max' : 3000, 'size' : 2, 'adr' : 8, 'pos' : [4, 1], 'min' : 0, 'name' : 'Yaw P', 'default' : 400, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'YawI' : {'len' : 7, 'steps' : 50, 'ppos' : 1, 'page' : 'pid', 'max' : 32000, 'size' : 2, 'adr' : 9, 'min' : 0, 'name' : 'Yaw I', 'default' : 1000, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'YawD' : {'len' : 3, 'steps' : 50, 'ppos' : 4, 'page' : 'pid', 'max' : 8000, 'size' : 2, 'adr' : 10, 'min' : 0, 'name' : 'Yaw D', 'default' : 500, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'YawMotorVmax' : {'len' : 5, 'steps' : 1, 'ppos' : 0, 'page' : 'pid', 'max' : 255, 'size' : 2, 'adr' : 11, 'min' : 0, 'name' : 'Yaw Motor Vmax', 'default' : 150, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'FocPitchP' : {'len' : 5, 'steps' : 10, 'ppos' : 2, 'page' : 'pid', 'max' : 3000, 'size' : 2, 'adr' : 23, 'pos' : [2, 1], 'min' : 0, 'name' : 'Foc Pitch P', 'default' : 400, 'foc' : 2, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'FocPitchI' : {'len' : 7, 'steps' : 50, 'ppos' : 1, 'page' : 'pid', 'max' : 32000, 'size' : 2, 'adr' : 24, 'min' : 0, 'name' : 'Foc Pitch I', 'default' : 100, 'foc' : 2, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'FocPitchD' : {'len' : 3, 'steps' : 50, 'ppos' : 4, 'page' : 'pid', 'max' : 8000, 'size' : 2, 'adr' : 25, 'min' : 0, 'name' : 'Foc Pitch D', 'default' : 2000, 'foc' : 2, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'FocPitchK' : {'len' : 5, 'steps' : 1, 'ppos' : 1, 'page' : 'pid', 'max' : 100, 'size' : 2, 'adr' : 26, 'min' : 1, 'name' : 'Foc Pitch K', 'default' : 10, 'foc' : 2, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'FocRollP' : {'len' : 5, 'steps' : 10, 'ppos' : 2, 'page' : 'pid', 'max' : 3000, 'size' : 2, 'adr' : 29, 'pos' : [3, 1], 'min' : 0, 'name' : 'Foc Roll P', 'default' : 400, 'foc' : 2, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'FocRollI' : {'len' : 7, 'steps' : 50, 'ppos' : 1, 'page' : 'pid', 'max' : 32000, 'size' : 2, 'adr' : 30, 'min' : 0, 'name' : 'Foc Roll I', 'default' : 100, 'foc' : 2, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'FocRollD' : {'len' : 3, 'steps' : 50, 'ppos' : 4, 'page' : 'pid', 'max' : 8000, 'size' : 2, 'adr' : 31, 'min' : 0, 'name' : 'Foc Roll D', 'default' : 2000, 'foc' : 2, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'FocRollK' : {'len' : 5, 'steps' : 1, 'ppos' : 1, 'page' : 'pid', 'max' : 100, 'size' : 2, 'adr' : 32, 'min' : 1, 'name' : 'Foc Roll K', 'default' : 10, 'foc' : 2, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'FocYawP' : {'len' : 5, 'steps' : 10, 'ppos' : 2, 'page' : 'pid', 'max' : 3000, 'size' : 2, 'adr' : 35, 'pos' : [4, 1], 'min' : 0, 'name' : 'Foc Yaw P', 'default' : 400, 'foc' : 2, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'FocYawI' : {'len' : 7, 'steps' : 50, 'ppos' : 1, 'page' : 'pid', 'max' : 32000, 'size' : 2, 'adr' : 36, 'min' : 0, 'name' : 'Foc Yaw I', 'default' : 100, 'foc' : 2, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'FocYawD' : {'len' : 3, 'steps' : 50, 'ppos' : 4, 'page' : 'pid', 'max' : 8000, 'size' : 2, 'adr' : 37, 'min' : 0, 'name' : 'Foc Yaw D', 'default' : 2000, 'foc' : 2, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'FocYawK' : {'len' : 5, 'steps' : 1, 'ppos' : 1, 'page' : 'pid', 'max' : 100, 'size' : 2, 'adr' : 38, 'min' : 1, 'name' : 'Foc Yaw K', 'default' : 10, 'foc' : 2, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'PanModeControl' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'pan', 'max' : 42, 'choices' : ['off', 'Rc-0', 'Rc-1', 'Rc-2', 'Rc2-0', 'Rc2-1', 'Rc2-2', 'Rc2-3', 'Pot-0', 'Pot-1', 'Pot-2', 'Virtual-1', 'Virtual-2', 'Virtual-3', 'Virtual-4', 'Virtual-5', 'Virtual-6', 'Virtual-7', 'Virtual-8', 'Virtual-9', 'Virtual-10', 'Virtual-11', 'Virtual-12', 'Virtual-13', 'Virtual-14', 'Virtual-15', 'Virtual-16', 'But switch', 'But latch', 'But step', 'Aux-0 switch', 'Aux-1 switch', 'Aux-2 switch', 'Aux-01 switch', 'Aux-012 switch', 'Aux-0 latch', 'Aux-1 latch', 'Aux-2 latch', 'Aux-01 latch', 'Aux-012 latch', 'Aux-0 step', 'Aux-1 step', 'Aux-2 step'], 'size' : 1, 'adr' : 79, 'column' : 1, 'min' : 0, 'name' : 'Pan Mode Control', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'PanModeDefaultSetting' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'pan', 'max' : 5, 'choices' : ['hold hold pan', 'hold hold hold', 'pan pan pan', 'pan hold hold', 'pan hold pan', 'hold pan pan', 'off'], 'size' : 1, 'adr' : 80, 'min' : 0, 'name' : 'Pan Mode Default Setting', 'default' : 0, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'PanModeSetting1' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'pan', 'max' : 6, 'choices' : ['hold hold pan', 'hold hold hold', 'pan pan pan', 'pan hold hold', 'pan hold pan', 'hold pan pan', 'off'], 'size' : 1, 'adr' : 81, 'min' : 0, 'name' : 'Pan Mode Setting #1', 'default' : 1, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'PanModeSetting2' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'pan', 'max' : 6, 'choices' : ['hold hold pan', 'hold hold hold', 'pan pan pan', 'pan hold hold', 'pan hold pan', 'hold pan pan', 'off'], 'size' : 1, 'adr' : 82, 'min' : 0, 'name' : 'Pan Mode Setting #2', 'default' : 4, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'PanModeSetting3' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'pan', 'max' : 6, 'choices' : ['hold hold pan', 'hold hold hold', 'pan pan pan', 'pan hold hold', 'pan hold pan', 'hold pan pan', 'off'], 'size' : 1, 'adr' : 83, 'min' : 0, 'name' : 'Pan Mode Setting #3', 'default' : 2, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'PitchPan' : {'len' : 5, 'steps' : 1, 'ppos' : 1, 'page' : 'pan', 'max' : 50, 'size' : 2, 'adr' : 84, 'column' : 2, 'min' : 0, 'name' : 'Pitch Pan', 'default' : 20, 'foc' : 0, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'PitchPanDeadband' : {'len' : 5, 'steps' : 10, 'ppos' : 1, 'page' : 'pan', 'max' : 600, 'size' : 2, 'adr' : 85, 'pos' : [2, 3], 'min' : 0, 'name' : 'Pitch Pan Deadband', 'default' : 0, 'foc' : 0, 'unit' : '\u00b0', 'type' : 'UINT', 'hidden' : 0},
  'PitchPanExpo' : {'len' : 5, 'steps' : 1, 'ppos' : 0, 'page' : 'pan', 'max' : 100, 'size' : 2, 'adr' : 86, 'min' : 0, 'name' : 'Pitch Pan Expo', 'default' : 0, 'foc' : 0, 'unit' : '%', 'type' : 'UINT', 'hidden' : 0},
  'RollPan' : {'len' : 5, 'steps' : 1, 'ppos' : 1, 'page' : 'pan', 'max' : 50, 'size' : 2, 'adr' : 87, 'column' : 3, 'min' : 0, 'name' : 'Roll Pan', 'default' : 20, 'foc' : 0, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'RollPanDeadband' : {'len' : 5, 'steps' : 10, 'ppos' : 1, 'page' : 'pan', 'max' : 600, 'size' : 2, 'adr' : 88, 'pos' : [3, 3], 'min' : 0, 'name' : 'Roll Pan Deadband', 'default' : 0, 'foc' : 0, 'unit' : '\u00b0', 'type' : 'UINT', 'hidden' : 0},
  'RollPanExpo' : {'len' : 5, 'steps' : 1, 'ppos' : 0, 'page' : 'pan', 'max' : 100, 'size' : 2, 'adr' : 89, 'min' : 0, 'name' : 'Roll Pan Expo', 'default' : 0, 'foc' : 0, 'unit' : '%', 'type' : 'UINT', 'hidden' : 0},
  'YawPan' : {'len' : 5, 'steps' : 1, 'ppos' : 1, 'page' : 'pan', 'max' : 50, 'size' : 2, 'adr' : 90, 'column' : 4, 'min' : 0, 'name' : 'Yaw Pan', 'default' : 20, 'foc' : 0, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'YawPanDeadband' : {'len' : 5, 'steps' : 5, 'ppos' : 1, 'page' : 'pan', 'max' : 100, 'size' : 2, 'adr' : 91, 'pos' : [4, 3], 'min' : 0, 'name' : 'Yaw Pan Deadband', 'default' : 50, 'foc' : 0, 'unit' : '\u00b0', 'type' : 'UINT', 'hidden' : 0},
  'YawPanExpo' : {'len' : 5, 'steps' : 1, 'ppos' : 0, 'page' : 'pan', 'max' : 100, 'size' : 2, 'adr' : 92, 'min' : 0, 'name' : 'Yaw Pan Expo', 'default' : 0, 'foc' : 0, 'unit' : '%', 'type' : 'UINT', 'hidden' : 0},
  'YawPanDeadbandLPF' : {'len' : 5, 'steps' : 5, 'ppos' : 2, 'page' : 'pan', 'max' : 400, 'size' : 2, 'adr' : 93, 'min' : 0, 'name' : 'Yaw Pan Deadband LPF', 'default' : 150, 'foc' : 0, 'unit' : 's', 'type' : 'UINT', 'hidden' : 0},
  'RcDeadBand' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'rcinputs', 'max' : 50, 'size' : 2, 'adr' : 96, 'min' : 0, 'name' : 'Rc Dead Band', 'default' : 10, 'foc' : 0, 'unit' : 'us', 'type' : 'UINT', 'hidden' : 0},
  'RcHysteresis' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'rcinputs', 'max' : 50, 'size' : 2, 'adr' : 97, 'min' : 0, 'name' : 'Rc Hysteresis', 'default' : 5, 'foc' : 0, 'unit' : 'us', 'type' : 'UINT', 'hidden' : 0},
  'RcPitchTrim' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'rcinputs', 'max' : 100, 'size' : 2, 'adr' : 104, 'pos' : [1, 4], 'min' : -100, 'name' : 'Rc Pitch Trim', 'default' : 0, 'foc' : 0, 'unit' : 'us', 'type' : 'INT', 'hidden' : 0},
  'RcRollTrim' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'rcinputs', 'max' : 100, 'size' : 2, 'adr' : 111, 'min' : -100, 'name' : 'Rc Roll Trim', 'default' : 0, 'foc' : 0, 'unit' : 'us', 'type' : 'INT', 'hidden' : 0},
  'RcYawTrim' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'rcinputs', 'max' : 100, 'size' : 2, 'adr' : 118, 'min' : -100, 'name' : 'Rc Yaw Trim', 'default' : 0, 'foc' : 0, 'unit' : 'us', 'type' : 'INT', 'hidden' : 0},
  'RcPitch' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'rcinputs', 'max' : 42, 'choices' : ['off', 'Rc-0', 'Rc-1', 'Rc-2', 'Rc2-0', 'Rc2-1', 'Rc2-2', 'Rc2-3', 'Pot-0', 'Pot-1', 'Pot-2', 'Virtual-1', 'Virtual-2', 'Virtual-3', 'Virtual-4', 'Virtual-5', 'Virtual-6', 'Virtual-7', 'Virtual-8', 'Virtual-9', 'Virtual-10', 'Virtual-11', 'Virtual-12', 'Virtual-13', 'Virtual-14', 'Virtual-15', 'Virtual-16', 'But switch', 'But latch', 'But step', 'Aux-0 switch', 'Aux-1 switch', 'Aux-2 switch', 'Aux-01 switch', 'Aux-012 switch', 'Aux-0 latch', 'Aux-1 latch', 'Aux-2 latch', 'Aux-01 latch', 'Aux-012 latch', 'Aux-0 step', 'Aux-1 step', 'Aux-2 step'], 'size' : 1, 'adr' : 102, 'column' : 2, 'min' : 0, 'name' : 'Rc Pitch', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'RcPitchMode' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'rcinputs', 'max' : 2, 'choices' : ['absolute', 'relative', 'absolute centered'], 'size' : 1, 'adr' : 103, 'min' : 0, 'name' : 'Rc Pitch Mode', 'default' : 0, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'RcPitchMin' : {'len' : 0, 'steps' : 5, 'ppos' : 1, 'page' : 'rcinputs', 'max' : 1200, 'size' : 2, 'adr' : 105, 'min' : -1200, 'name' : 'Rc Pitch Min', 'default' : -250, 'foc' : 0, 'unit' : '\u00b0', 'type' : 'INT', 'hidden' : 0},
  'RcPitchMax' : {'len' : 0, 'steps' : 5, 'ppos' : 1, 'page' : 'rcinputs', 'max' : 1200, 'size' : 2, 'adr' : 106, 'min' : -1200, 'name' : 'Rc Pitch Max', 'default' : 250, 'foc' : 0, 'unit' : '\u00b0', 'type' : 'INT', 'hidden' : 0},
  'RcPitchSpeedLimit' : {'len' : 0, 'steps' : 5, 'ppos' : 1, 'page' : 'rcinputs', 'max' : 1000, 'size' : 2, 'adr' : 107, 'min' : 0, 'name' : 'Rc Pitch Speed Limit', 'default' : 400, 'foc' : 0, 'unit' : '\u00b0/s', 'type' : 'UINT', 'hidden' : 0},
  'RcPitchAccelLimit' : {'len' : 0, 'steps' : 10, 'ppos' : 3, 'page' : 'rcinputs', 'max' : 1000, 'size' : 2, 'adr' : 108, 'min' : 0, 'name' : 'Rc Pitch Accel Limit', 'default' : 300, 'foc' : 0, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'RcRoll' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'rcinputs', 'max' : 42, 'choices' : ['off', 'Rc-0', 'Rc-1', 'Rc-2', 'Rc2-0', 'Rc2-1', 'Rc2-2', 'Rc2-3', 'Pot-0', 'Pot-1', 'Pot-2', 'Virtual-1', 'Virtual-2', 'Virtual-3', 'Virtual-4', 'Virtual-5', 'Virtual-6', 'Virtual-7', 'Virtual-8', 'Virtual-9', 'Virtual-10', 'Virtual-11', 'Virtual-12', 'Virtual-13', 'Virtual-14', 'Virtual-15', 'Virtual-16', 'But switch', 'But latch', 'But step', 'Aux-0 switch', 'Aux-1 switch', 'Aux-2 switch', 'Aux-01 switch', 'Aux-012 switch', 'Aux-0 latch', 'Aux-1 latch', 'Aux-2 latch', 'Aux-01 latch', 'Aux-012 latch', 'Aux-0 step', 'Aux-1 step', 'Aux-2 step'], 'size' : 1, 'adr' : 109, 'column' : 3, 'min' : 0, 'name' : 'Rc Roll', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'RcRollMode' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'rcinputs', 'max' : 2, 'choices' : ['absolute', 'relative', 'absolute centered'], 'size' : 1, 'adr' : 110, 'min' : 0, 'name' : 'Rc Roll Mode', 'default' : 0, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'RcRollMin' : {'len' : 0, 'steps' : 5, 'ppos' : 1, 'page' : 'rcinputs', 'max' : 450, 'size' : 2, 'adr' : 112, 'min' : -450, 'name' : 'Rc Roll Min', 'default' : -250, 'foc' : 0, 'unit' : '\u00b0', 'type' : 'INT', 'hidden' : 0},
  'RcRollMax' : {'len' : 0, 'steps' : 5, 'ppos' : 1, 'page' : 'rcinputs', 'max' : 450, 'size' : 2, 'adr' : 113, 'min' : -450, 'name' : 'Rc Roll Max', 'default' : 250, 'foc' : 0, 'unit' : '\u00b0', 'type' : 'INT', 'hidden' : 0},
  'RcRollSpeedLimit' : {'len' : 0, 'steps' : 5, 'ppos' : 1, 'page' : 'rcinputs', 'max' : 1000, 'size' : 2, 'adr' : 114, 'min' : 0, 'name' : 'Rc Roll Speed Limit', 'default' : 400, 'foc' : 0, 'unit' : '\u00b0/s', 'type' : 'UINT', 'hidden' : 0},
  'RcRollAccelLimit' : {'len' : 0, 'steps' : 10, 'ppos' : 3, 'page' : 'rcinputs', 'max' : 1000, 'size' : 2, 'adr' : 115, 'min' : 0, 'name' : 'Rc Roll Accel Limit', 'default' : 300, 'foc' : 0, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'RcYaw' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'rcinputs', 'max' : 42, 'choices' : ['off', 'Rc-0', 'Rc-1', 'Rc-2', 'Rc2-0', 'Rc2-1', 'Rc2-2', 'Rc2-3', 'Pot-0', 'Pot-1', 'Pot-2', 'Virtual-1', 'Virtual-2', 'Virtual-3', 'Virtual-4', 'Virtual-5', 'Virtual-6', 'Virtual-7', 'Virtual-8', 'Virtual-9', 'Virtual-10', 'Virtual-11', 'Virtual-12', 'Virtual-13', 'Virtual-14', 'Virtual-15', 'Virtual-16', 'But switch', 'But latch', 'But step', 'Aux-0 switch', 'Aux-1 switch', 'Aux-2 switch', 'Aux-01 switch', 'Aux-012 switch', 'Aux-0 latch', 'Aux-1 latch', 'Aux-2 latch', 'Aux-01 latch', 'Aux-012 latch', 'Aux-0 step', 'Aux-1 step', 'Aux-2 step'], 'size' : 1, 'adr' : 116, 'column' : 4, 'min' : 0, 'name' : 'Rc Yaw', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'RcYawMode' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'rcinputs', 'max' : 3, 'choices' : ['absolute', 'relative', 'absolute centered', 'relative turn around'], 'size' : 1, 'adr' : 117, 'min' : 0, 'name' : 'Rc Yaw Mode', 'default' : 0, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'RcYawMin' : {'len' : 0, 'steps' : 10, 'ppos' : 1, 'page' : 'rcinputs', 'max' : 2700, 'size' : 2, 'adr' : 119, 'min' : -2700, 'name' : 'Rc Yaw Min', 'default' : -250, 'foc' : 0, 'unit' : '\u00b0', 'type' : 'INT', 'hidden' : 0},
  'RcYawMax' : {'len' : 0, 'steps' : 10, 'ppos' : 1, 'page' : 'rcinputs', 'max' : 2700, 'size' : 2, 'adr' : 120, 'min' : -2700, 'name' : 'Rc Yaw Max', 'default' : 250, 'foc' : 0, 'unit' : '\u00b0', 'type' : 'INT', 'hidden' : 0},
  'RcYawSpeedLimit' : {'len' : 0, 'steps' : 5, 'ppos' : 1, 'page' : 'rcinputs', 'max' : 1000, 'size' : 2, 'adr' : 121, 'min' : 0, 'name' : 'Rc Yaw Speed Limit', 'default' : 400, 'foc' : 0, 'unit' : '\u00b0/s', 'type' : 'UINT', 'hidden' : 0},
  'RcYawAccelLimit' : {'len' : 0, 'steps' : 10, 'ppos' : 3, 'page' : 'rcinputs', 'max' : 1000, 'size' : 2, 'adr' : 122, 'min' : 0, 'name' : 'Rc Yaw Accel Limit', 'default' : 300, 'foc' : 0, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'Standby' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'functions', 'max' : 42, 'choices' : ['off', 'Rc-0', 'Rc-1', 'Rc-2', 'Rc2-0', 'Rc2-1', 'Rc2-2', 'Rc2-3', 'Pot-0', 'Pot-1', 'Pot-2', 'Virtual-1', 'Virtual-2', 'Virtual-3', 'Virtual-4', 'Virtual-5', 'Virtual-6', 'Virtual-7', 'Virtual-8', 'Virtual-9', 'Virtual-10', 'Virtual-11', 'Virtual-12', 'Virtual-13', 'Virtual-14', 'Virtual-15', 'Virtual-16', 'But switch', 'But latch', 'But step', 'Aux-0 switch', 'Aux-1 switch', 'Aux-2 switch', 'Aux-01 switch', 'Aux-012 switch', 'Aux-0 latch', 'Aux-1 latch', 'Aux-2 latch', 'Aux-01 latch', 'Aux-012 latch', 'Aux-0 step', 'Aux-1 step', 'Aux-2 step'], 'size' : 1, 'adr' : 123, 'column' : 1, 'min' : 0, 'name' : 'Standby', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'RecenterCamera' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'functions', 'max' : 42, 'choices' : ['off', 'Rc-0', 'Rc-1', 'Rc-2', 'Rc2-0', 'Rc2-1', 'Rc2-2', 'Rc2-3', 'Pot-0', 'Pot-1', 'Pot-2', 'Virtual-1', 'Virtual-2', 'Virtual-3', 'Virtual-4', 'Virtual-5', 'Virtual-6', 'Virtual-7', 'Virtual-8', 'Virtual-9', 'Virtual-10', 'Virtual-11', 'Virtual-12', 'Virtual-13', 'Virtual-14', 'Virtual-15', 'Virtual-16', 'But switch', 'But latch', 'But step', 'Aux-0 switch', 'Aux-1 switch', 'Aux-2 switch', 'Aux-01 switch', 'Aux-012 switch', 'Aux-0 latch', 'Aux-1 latch', 'Aux-2 latch', 'Aux-01 latch', 'Aux-012 latch', 'Aux-0 step', 'Aux-1 step', 'Aux-2 step'], 'size' : 1, 'adr' : 124, 'pos' : [1, 3], 'min' : 0, 'name' : 'Re-center Camera', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'IRCameraControl' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'functions', 'max' : 42, 'choices' : ['off', 'Rc-0', 'Rc-1', 'Rc-2', 'Rc2-0', 'Rc2-1', 'Rc2-2', 'Rc2-3', 'Pot-0', 'Pot-1', 'Pot-2', 'Virtual-1', 'Virtual-2', 'Virtual-3', 'Virtual-4', 'Virtual-5', 'Virtual-6', 'Virtual-7', 'Virtual-8', 'Virtual-9', 'Virtual-10', 'Virtual-11', 'Virtual-12', 'Virtual-13', 'Virtual-14', 'Virtual-15', 'Virtual-16', 'But switch', 'But latch', 'But step', 'Aux-0 switch', 'Aux-1 switch', 'Aux-2 switch', 'Aux-01 switch', 'Aux-012 switch', 'Aux-0 latch', 'Aux-1 latch', 'Aux-2 latch', 'Aux-01 latch', 'Aux-012 latch', 'Aux-0 step', 'Aux-1 step', 'Aux-2 step'], 'size' : 1, 'adr' : 125, 'column' : 2, 'min' : 0, 'name' : 'IR Camera Control', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'CameraModel' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'functions', 'max' : 5, 'choices' : ['Sony Nex', 'Canon', 'Panasonic', 'Nikon', 'Git2 Rc', 'CAMremote'], 'size' : 1, 'adr' : 126, 'min' : 0, 'name' : 'Camera Model', 'default' : 0, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'IRCameraSetting1' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'functions', 'max' : 2, 'choices' : ['shutter', 'shutter delay', 'video on/off'], 'size' : 1, 'adr' : 127, 'min' : 0, 'name' : 'IR Camera Setting #1', 'default' : 0, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'IRCameraSetting2' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'functions', 'max' : 3, 'choices' : ['shutter', 'shutter delay', 'video on/off', 'off'], 'size' : 1, 'adr' : 128, 'min' : 0, 'name' : 'IR Camera Setting #2', 'default' : 2, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'TimeInterval' : {'len' : 0, 'steps' : 1, 'ppos' : 1, 'page' : 'functions', 'max' : 150, 'size' : 2, 'adr' : 129, 'min' : 0, 'name' : 'Time Interval', 'default' : 0, 'foc' : 0, 'unit' : 's', 'type' : 'UINT', 'hidden' : 0},
  'PwmOutControl' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'functions', 'max' : 42, 'choices' : ['off', 'Rc-0', 'Rc-1', 'Rc-2', 'Rc2-0', 'Rc2-1', 'Rc2-2', 'Rc2-3', 'Pot-0', 'Pot-1', 'Pot-2', 'Virtual-1', 'Virtual-2', 'Virtual-3', 'Virtual-4', 'Virtual-5', 'Virtual-6', 'Virtual-7', 'Virtual-8', 'Virtual-9', 'Virtual-10', 'Virtual-11', 'Virtual-12', 'Virtual-13', 'Virtual-14', 'Virtual-15', 'Virtual-16', 'But switch', 'But latch', 'But step', 'Aux-0 switch', 'Aux-1 switch', 'Aux-2 switch', 'Aux-01 switch', 'Aux-012 switch', 'Aux-0 latch', 'Aux-1 latch', 'Aux-2 latch', 'Aux-01 latch', 'Aux-012 latch', 'Aux-0 step', 'Aux-1 step', 'Aux-2 step'], 'size' : 1, 'adr' : 130, 'column' : 3, 'min' : 0, 'name' : 'Pwm Out Control', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'PwmOutMid' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'functions', 'max' : 2100, 'size' : 2, 'adr' : 131, 'min' : 900, 'name' : 'Pwm Out Mid', 'default' : 1500, 'foc' : 0, 'unit' : 'us', 'type' : 'UINT', 'hidden' : 0},
  'PwmOutMin' : {'len' : 0, 'steps' : 10, 'ppos' : 0, 'page' : 'functions', 'max' : 2100, 'size' : 2, 'adr' : 132, 'min' : 900, 'name' : 'Pwm Out Min', 'default' : 1100, 'foc' : 0, 'unit' : 'us', 'type' : 'UINT', 'hidden' : 0},
  'PwmOutMax' : {'len' : 0, 'steps' : 10, 'ppos' : 0, 'page' : 'functions', 'max' : 2100, 'size' : 2, 'adr' : 133, 'min' : 900, 'name' : 'Pwm Out Max', 'default' : 1900, 'foc' : 0, 'unit' : 'us', 'type' : 'UINT', 'hidden' : 0},
  'PwmOutSpeedLimit' : {'len' : 0, 'steps' : 5, 'ppos' : 0, 'page' : 'functions', 'max' : 1000, 'size' : 2, 'adr' : 134, 'min' : 0, 'name' : 'Pwm Out Speed Limit', 'default' : 0, 'foc' : 0, 'unit' : 'us/s', 'type' : 'UINT', 'hidden' : 0},
  'Script1Control' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'scripts', 'max' : 42, 'choices' : ['off', 'Rc-0', 'Rc-1', 'Rc-2', 'Rc2-0', 'Rc2-1', 'Rc2-2', 'Rc2-3', 'Pot-0', 'Pot-1', 'Pot-2', 'Virtual-1', 'Virtual-2', 'Virtual-3', 'Virtual-4', 'Virtual-5', 'Virtual-6', 'Virtual-7', 'Virtual-8', 'Virtual-9', 'Virtual-10', 'Virtual-11', 'Virtual-12', 'Virtual-13', 'Virtual-14', 'Virtual-15', 'Virtual-16', 'But switch', 'But latch', 'But step', 'Aux-0 switch', 'Aux-1 switch', 'Aux-2 switch', 'Aux-01 switch', 'Aux-012 switch', 'Aux-0 latch', 'Aux-1 latch', 'Aux-2 latch', 'Aux-01 latch', 'Aux-012 latch', 'Aux-0 step', 'Aux-1 step', 'Aux-2 step'], 'size' : 1, 'adr' : 150, 'column' : 1, 'min' : 0, 'name' : 'Script1 Control', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'Script2Control' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'scripts', 'max' : 42, 'choices' : ['off', 'Rc-0', 'Rc-1', 'Rc-2', 'Rc2-0', 'Rc2-1', 'Rc2-2', 'Rc2-3', 'Pot-0', 'Pot-1', 'Pot-2', 'Virtual-1', 'Virtual-2', 'Virtual-3', 'Virtual-4', 'Virtual-5', 'Virtual-6', 'Virtual-7', 'Virtual-8', 'Virtual-9', 'Virtual-10', 'Virtual-11', 'Virtual-12', 'Virtual-13', 'Virtual-14', 'Virtual-15', 'Virtual-16', 'But switch', 'But latch', 'But step', 'Aux-0 switch', 'Aux-1 switch', 'Aux-2 switch', 'Aux-01 switch', 'Aux-012 switch', 'Aux-0 latch', 'Aux-1 latch', 'Aux-2 latch', 'Aux-01 latch', 'Aux-012 latch', 'Aux-0 step', 'Aux-1 step', 'Aux-2 step'], 'size' : 1, 'adr' : 151, 'column' : 2, 'min' : 0, 'name' : 'Script2 Control', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'Script3Control' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'scripts', 'max' : 42, 'choices' : ['off', 'Rc-0', 'Rc-1', 'Rc-2', 'Rc2-0', 'Rc2-1', 'Rc2-2', 'Rc2-3', 'Pot-0', 'Pot-1', 'Pot-2', 'Virtual-1', 'Virtual-2', 'Virtual-3', 'Virtual-4', 'Virtual-5', 'Virtual-6', 'Virtual-7', 'Virtual-8', 'Virtual-9', 'Virtual-10', 'Virtual-11', 'Virtual-12', 'Virtual-13', 'Virtual-14', 'Virtual-15', 'Virtual-16', 'But switch', 'But latch', 'But step', 'Aux-0 switch', 'Aux-1 switch', 'Aux-2 switch', 'Aux-01 switch', 'Aux-012 switch', 'Aux-0 latch', 'Aux-1 latch', 'Aux-2 latch', 'Aux-01 latch', 'Aux-012 latch', 'Aux-0 step', 'Aux-1 step', 'Aux-2 step'], 'size' : 1, 'adr' : 152, 'column' : 3, 'min' : 0, 'name' : 'Script3 Control', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'Script4Control' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'scripts', 'max' : 42, 'choices' : ['off', 'Rc-0', 'Rc-1', 'Rc-2', 'Rc2-0', 'Rc2-1', 'Rc2-2', 'Rc2-3', 'Pot-0', 'Pot-1', 'Pot-2', 'Virtual-1', 'Virtual-2', 'Virtual-3', 'Virtual-4', 'Virtual-5', 'Virtual-6', 'Virtual-7', 'Virtual-8', 'Virtual-9', 'Virtual-10', 'Virtual-11', 'Virtual-12', 'Virtual-13', 'Virtual-14', 'Virtual-15', 'Virtual-16', 'But switch', 'But latch', 'But step', 'Aux-0 switch', 'Aux-1 switch', 'Aux-2 switch', 'Aux-01 switch', 'Aux-012 switch', 'Aux-0 latch', 'Aux-1 latch', 'Aux-2 latch', 'Aux-01 latch', 'Aux-012 latch', 'Aux-0 step', 'Aux-1 step', 'Aux-2 step'], 'size' : 1, 'adr' : 153, 'column' : 4, 'min' : 0, 'name' : 'Script4 Control', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'Scripts' : {'len' : 0, 'steps' : 0, 'ppos' : 0, 'page' : 'scripts', 'max' : 0, 'size' : 128, 'adr' : 154, 'min' : 0, 'name' : 'Scripts', 'default' : '', 'foc' : 0, 'unit' : '', 'type' : 'SCRIPT', 'hidden' : 1},
  'Imu2Configuration' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'setup', 'max' : 2, 'choices' : ['off', 'full', 'full xy'], 'size' : 1, 'adr' : 53, 'min' : 0, 'name' : 'Imu2 Configuration', 'default' : 0, 'foc' : 3, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'StartupMode' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'setup', 'max' : 1, 'choices' : ['normal', 'fast'], 'size' : 1, 'adr' : 140, 'pos' : [1, 4], 'min' : 0, 'name' : 'Startup Mode', 'default' : 0, 'foc' : 3, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'StartupDelay' : {'len' : 0, 'steps' : 5, 'ppos' : 1, 'page' : 'setup', 'max' : 250, 'size' : 2, 'adr' : 141, 'min' : 0, 'name' : 'Startup Delay', 'default' : 0, 'foc' : 0, 'unit' : 's', 'type' : 'UINT', 'hidden' : 0},
  'ImuAHRS' : {'len' : 5, 'steps' : 100, 'ppos' : 2, 'page' : 'setup', 'max' : 2500, 'size' : 2, 'adr' : 61, 'min' : 0, 'name' : 'Imu AHRS', 'default' : 1000, 'foc' : 0, 'unit' : 's', 'type' : 'UINT', 'hidden' : 0},
  'VirtualChannelConfiguration' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'setup', 'max' : 11, 'choices' : ['off', 'sum ppm 6', 'sum ppm 7', 'sum ppm 8', 'sum ppm 10', 'sum ppm 12', 'spektrum 10 bit', 'spektrum 11 bit', 'sbus', 'hott sumd', 'srxl', 'serial'], 'size' : 1, 'adr' : 77, 'column' : 2, 'min' : 0, 'name' : 'Virtual Channel Configuration', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'PwmOutConfiguration' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'setup', 'max' : 2, 'choices' : ['off', '1520 us 55 Hz', '1520 us 250 Hz'], 'size' : 1, 'adr' : 78, 'min' : 0, 'name' : 'Pwm Out Configuration', 'default' : 0, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'RcPitchOffset' : {'len' : 0, 'steps' : 5, 'ppos' : 1, 'page' : 'setup', 'max' : 1200, 'size' : 2, 'adr' : 99, 'pos' : [2, 4], 'min' : -1200, 'name' : 'Rc Pitch Offset', 'default' : 0, 'foc' : 0, 'unit' : '\u00b0', 'type' : 'INT', 'hidden' : 0},
  'RcRollOffset' : {'len' : 0, 'steps' : 5, 'ppos' : 1, 'page' : 'setup', 'max' : 1200, 'size' : 2, 'adr' : 100, 'min' : -1200, 'name' : 'Rc Roll Offset', 'default' : 0, 'foc' : 0, 'unit' : '\u00b0', 'type' : 'INT', 'hidden' : 0},
  'RcYawOffset' : {'len' : 0, 'steps' : 5, 'ppos' : 1, 'page' : 'setup', 'max' : 1200, 'size' : 2, 'adr' : 101, 'min' : -1200, 'name' : 'Rc Yaw Offset', 'default' : 0, 'foc' : 0, 'unit' : '\u00b0', 'type' : 'INT', 'hidden' : 0},
  'EspConfiguration' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'setup', 'max' : 2, 'choices' : ['off', 'uart', 'uart2'], 'size' : 1, 'adr' : 147, 'pos' : [3, 1], 'min' : 0, 'name' : 'Esp Configuration', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'LowVoltageLimit' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'setup', 'max' : 7, 'choices' : ['off', '2.9 V/cell', '3.0 V/cell', '3.1 V/cell', '3.2 V/cell', '3.3 V/cell', '3.4 V/cell', '3.5 V/cell'], 'size' : 1, 'adr' : 74, 'pos' : [3, 4], 'min' : 0, 'name' : 'Low Voltage Limit', 'default' : 1, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'BeepwithMotors' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'setup', 'max' : 2, 'choices' : ['off', 'basic', 'all'], 'size' : 1, 'adr' : 143, 'min' : 0, 'name' : 'Beep with Motors', 'default' : 0, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'NTLogging' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'setup', 'max' : 7, 'choices' : ['off', 'basic', 'basic + pid', 'basic + accgyro', 'basic + accgyro_raw', 'basic + pid + accgyro', 'basic + pid + ag_raw', 'full'], 'size' : 1, 'adr' : 142, 'min' : 0, 'name' : 'NT Logging', 'default' : 0, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'PitchMotorUsage' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'setup', 'max' : 3, 'choices' : ['normal', 'level', 'startup pos', 'disabled'], 'size' : 1, 'adr' : 55, 'column' : 4, 'min' : 0, 'name' : 'Pitch Motor Usage', 'default' : 3, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'RollMotorUsage' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'setup', 'max' : 3, 'choices' : ['normal', 'level', 'startup pos', 'disabled'], 'size' : 1, 'adr' : 56, 'min' : 0, 'name' : 'Roll Motor Usage', 'default' : 3, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'YawMotorUsage' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'setup', 'max' : 3, 'choices' : ['normal', 'level', 'startup pos', 'disabled'], 'size' : 1, 'adr' : 57, 'min' : 0, 'name' : 'Yaw Motor Usage', 'default' : 3, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'ImuOrientation' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 23, 'choices' : ['no.0 :  z0\u00b0   x  y  z', 'no.1 :  z90\u00b0  -y  x  z', 'no.2 :  z180\u00b0  -x -y  z', 'no.3 :  z270\u00b0   y -x  z', 'no.4 :  x0\u00b0   y  z  x', 'no.5 :  x90\u00b0  -z  y  x', 'no.6 :  x180\u00b0  -y -z  x', 'no.7 :  x270\u00b0   z -y  x', 'no.8 :  y0\u00b0   z  x  y', 'no.9 :  y90\u00b0  -x  z  y', 'no.10 :  y180\u00b0  -z -x  y', 'no.11 :  y270\u00b0   x -z  y', 'no.12 :  -z0\u00b0   y  x -z', 'no.13 :  -z90\u00b0  -x  y -z', 'no.14 :  -z180\u00b0  -y -x -z', 'no.15 :  -z270\u00b0   x -y -z', 'no.16 :  -x0\u00b0   z  y -x', 'no.17 :  -x90\u00b0  -y  z -x', 'no.18 :  -x180\u00b0  -z -y -x', 'no.19 :  -x270\u00b0   y -z -x', 'no.20 :  -y0\u00b0   x  z -y', 'no.21 :  -y90\u00b0  -z  x -y', 'no.22 :  -y180\u00b0  -x -z -y', 'no.23 :  -y270\u00b0   z -x -y'], 'size' : 1, 'adr' : 51, 'pos' : [1, 1], 'min' : 0, 'name' : 'Imu Orientation', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'Imu2Orientation' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 23, 'choices' : ['no.0 :  z0\u00b0   x  y  z', 'no.1 :  z90\u00b0  -y  x  z', 'no.2 :  z180\u00b0  -x -y  z', 'no.3 :  z270\u00b0   y -x  z', 'no.4 :  x0\u00b0   y  z  x', 'no.5 :  x90\u00b0  -z  y  x', 'no.6 :  x180\u00b0  -y -z  x', 'no.7 :  x270\u00b0   z -y  x', 'no.8 :  y0\u00b0   z  x  y', 'no.9 :  y90\u00b0  -x  z  y', 'no.10 :  y180\u00b0  -z -x  y', 'no.11 :  y270\u00b0   x -z  y', 'no.12 :  -z0\u00b0   y  x -z', 'no.13 :  -z90\u00b0  -x  y -z', 'no.14 :  -z180\u00b0  -y -x -z', 'no.15 :  -z270\u00b0   x -y -z', 'no.16 :  -x0\u00b0   z  y -x', 'no.17 :  -x90\u00b0  -y  z -x', 'no.18 :  -x180\u00b0  -z -y -x', 'no.19 :  -x270\u00b0   y -z -x', 'no.20 :  -y0\u00b0   x  z -y', 'no.21 :  -y90\u00b0  -z  x -y', 'no.22 :  -y180\u00b0  -x -z -y', 'no.23 :  -y270\u00b0   z -x -y'], 'size' : 1, 'adr' : 54, 'min' : 0, 'name' : 'Imu2 Orientation', 'default' : 0, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'PitchMotorPoles' : {'len' : 0, 'steps' : 2, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 28, 'size' : 2, 'adr' : 13, 'pos' : [2, 1], 'min' : 8, 'name' : 'Pitch Motor Poles', 'default' : 14, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'PitchMotorDirection' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 2, 'choices' : ['normal', 'reversed', 'auto'], 'size' : 1, 'adr' : 14, 'min' : 0, 'name' : 'Pitch Motor Direction', 'default' : 2, 'foc' : 1, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'PitchStartupMotorPos' : {'len' : 5, 'steps' : 1, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 1008, 'size' : 2, 'adr' : 15, 'min' : 0, 'name' : 'Pitch Startup Motor Pos', 'default' : 504, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'FocPitchMotorDirection' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 1, 'choices' : ['normal', 'reversed', 'auto'], 'size' : 1, 'adr' : 42, 'pos' : [2, 1], 'min' : 0, 'name' : 'Foc Pitch Motor Direction', 'default' : 0, 'foc' : 2, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'FocPitchZeroPos' : {'len' : 5, 'steps' : 8, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 16383, 'size' : 2, 'adr' : 43, 'min' : -16384, 'name' : 'Foc Pitch Zero Pos', 'default' : 0, 'foc' : 2, 'unit' : '', 'type' : 'INT', 'hidden' : 0},
  'PitchOffset' : {'len' : 5, 'steps' : 5, 'ppos' : 2, 'page' : 'gimbalconfig', 'max' : 300, 'size' : 2, 'adr' : 58, 'pos' : [2, 4], 'min' : -300, 'name' : 'Pitch Offset', 'default' : 0, 'foc' : 0, 'unit' : '\u00b0', 'type' : 'INT', 'hidden' : 0},
  'RollMotorPoles' : {'len' : 0, 'steps' : 2, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 28, 'size' : 2, 'adr' : 16, 'pos' : [3, 1], 'min' : 8, 'name' : 'Roll Motor Poles', 'default' : 14, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'RollMotorDirection' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 2, 'choices' : ['normal', 'reversed', 'auto'], 'size' : 1, 'adr' : 17, 'min' : 0, 'name' : 'Roll Motor Direction', 'default' : 2, 'foc' : 1, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'RollStartupMotorPos' : {'len' : 5, 'steps' : 1, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 1008, 'size' : 2, 'adr' : 18, 'min' : 0, 'name' : 'Roll Startup Motor Pos', 'default' : 504, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'FocRollMotorDirection' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 1, 'choices' : ['normal', 'reversed', 'auto'], 'size' : 1, 'adr' : 44, 'pos' : [3, 1], 'min' : 0, 'name' : 'Foc Roll Motor Direction', 'default' : 0, 'foc' : 2, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'FocRollZeroPos' : {'len' : 5, 'steps' : 8, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 16383, 'size' : 2, 'adr' : 45, 'min' : -16384, 'name' : 'Foc Roll Zero Pos', 'default' : 0, 'foc' : 2, 'unit' : '', 'type' : 'INT', 'hidden' : 0},
  'RollOffset' : {'len' : 5, 'steps' : 5, 'ppos' : 2, 'page' : 'gimbalconfig', 'max' : 300, 'size' : 2, 'adr' : 59, 'pos' : [3, 4], 'min' : -300, 'name' : 'Roll Offset', 'default' : 0, 'foc' : 0, 'unit' : '\u00b0', 'type' : 'INT', 'hidden' : 0},
  'YawMotorPoles' : {'len' : 0, 'steps' : 2, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 28, 'size' : 2, 'adr' : 19, 'pos' : [4, 1], 'min' : 8, 'name' : 'Yaw Motor Poles', 'default' : 14, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'YawMotorDirection' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 2, 'choices' : ['normal', 'reversed', 'auto'], 'size' : 1, 'adr' : 20, 'min' : 0, 'name' : 'Yaw Motor Direction', 'default' : 2, 'foc' : 1, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'YawStartupMotorPos' : {'len' : 5, 'steps' : 1, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 1008, 'size' : 2, 'adr' : 21, 'min' : 0, 'name' : 'Yaw Startup Motor Pos', 'default' : 504, 'foc' : 1, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'FocYawMotorDirection' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 1, 'choices' : ['normal', 'reversed', 'auto'], 'size' : 1, 'adr' : 46, 'pos' : [4, 1], 'min' : 0, 'name' : 'Foc Yaw Motor Direction', 'default' : 0, 'foc' : 2, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'FocYawZeroPos' : {'len' : 5, 'steps' : 8, 'ppos' : 0, 'page' : 'gimbalconfig', 'max' : 16383, 'size' : 2, 'adr' : 47, 'min' : -16384, 'name' : 'Foc Yaw Zero Pos', 'default' : 0, 'foc' : 2, 'unit' : '', 'type' : 'INT', 'hidden' : 0},
  'YawOffset' : {'len' : 5, 'steps' : 5, 'ppos' : 2, 'page' : 'gimbalconfig', 'max' : 300, 'size' : 2, 'adr' : 60, 'pos' : [4, 4], 'min' : -300, 'name' : 'Yaw Offset', 'default' : 0, 'foc' : 0, 'unit' : '\u00b0', 'type' : 'INT', 'hidden' : 0},
  'AccLPF' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'expert', 'max' : 6, 'choices' : ['off', '1.5 ms', '4.5 ms', '12 ms', '25 ms', '50 ms', '100 ms'], 'size' : 1, 'adr' : 71, 'min' : 0, 'name' : 'Acc LPF', 'default' : 2, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'RcAdcLPF' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'expert', 'max' : 6, 'choices' : ['off', '1.5 ms', '4.5 ms', '12 ms', '25 ms', '50 ms', '100 ms'], 'size' : 1, 'adr' : 98, 'min' : 0, 'name' : 'Rc Adc LPF', 'default' : 0, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'HoldToPanTransitionTime' : {'len' : 5, 'steps' : 25, 'ppos' : 0, 'page' : 'expert', 'max' : 1000, 'size' : 2, 'adr' : 95, 'min' : 0, 'name' : 'Hold To Pan Transition Time', 'default' : 250, 'foc' : 0, 'unit' : 'ms', 'type' : 'UINT', 'hidden' : 0},
  'AccCompensationMethod' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'expert', 'max' : 1, 'choices' : ['standard', 'advanced'], 'size' : 1, 'adr' : 65, 'pos' : [1, 6], 'min' : 0, 'name' : 'Acc Compensation Method', 'default' : 1, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'ImuAccThreshold' : {'len' : 5, 'steps' : 1, 'ppos' : 2, 'page' : 'expert', 'max' : 100, 'size' : 2, 'adr' : 64, 'column' : 2, 'min' : 0, 'name' : 'Imu Acc Threshold', 'default' : 25, 'foc' : 0, 'unit' : 'g', 'type' : 'UINT', 'hidden' : 0},
  'AccNoiseLevel' : {'len' : 0, 'steps' : 1, 'ppos' : 3, 'page' : 'expert', 'max' : 150, 'size' : 2, 'adr' : 66, 'min' : 0, 'name' : 'Acc Noise Level', 'default' : 40, 'foc' : 0, 'unit' : 'g', 'type' : 'UINT', 'hidden' : 0},
  'AccThreshold' : {'len' : 0, 'steps' : 1, 'ppos' : 2, 'page' : 'expert', 'max' : 100, 'size' : 2, 'adr' : 67, 'min' : 0, 'name' : 'Acc Threshold', 'default' : 50, 'foc' : 0, 'unit' : 'g', 'type' : 'UINT', 'hidden' : 0},
  'AccVerticalWeight' : {'len' : 0, 'steps' : 5, 'ppos' : 0, 'page' : 'expert', 'max' : 100, 'size' : 2, 'adr' : 68, 'min' : 0, 'name' : 'Acc Vertical Weight', 'default' : 25, 'foc' : 0, 'unit' : '%', 'type' : 'UINT', 'hidden' : 0},
  'AccZentrifugalCorrection' : {'len' : 0, 'steps' : 5, 'ppos' : 0, 'page' : 'expert', 'max' : 100, 'size' : 2, 'adr' : 69, 'min' : 0, 'name' : 'Acc Zentrifugal Correction', 'default' : 30, 'foc' : 0, 'unit' : '%', 'type' : 'UINT', 'hidden' : 0},
  'AccRecoverTime' : {'len' : 0, 'steps' : 5, 'ppos' : 0, 'page' : 'expert', 'max' : 1000, 'size' : 2, 'adr' : 70, 'min' : 0, 'name' : 'Acc Recover Time', 'default' : 250, 'foc' : 0, 'unit' : ' ms', 'type' : 'UINT', 'hidden' : 0},
  'MotorMapping' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'expert', 'max' : 5, 'choices' : ['M0=pitch , M1=roll', 'M0=roll , M1=pitch', 'roll yaw pitch', 'yaw roll pitch', 'pitch yaw roll', 'yaw pitch roll'], 'size' : 1, 'adr' : 22, 'column' : 3, 'min' : 0, 'name' : 'Motor Mapping', 'default' : 0, 'foc' : 3, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'ImuMapping' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'expert', 'max' : 1, 'choices' : ['1 = id1 , 2 = id2', '1 = id2 , 2 = id1'], 'size' : 1, 'adr' : 52, 'min' : 0, 'name' : 'Imu Mapping', 'default' : 0, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'ADCCalibration' : {'len' : 0, 'steps' : 10, 'ppos' : 0, 'page' : 'expert', 'max' : 2000, 'size' : 2, 'adr' : 76, 'min' : 1000, 'name' : 'ADC Calibration', 'default' : 1550, 'foc' : 0, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'Imu3Configuration' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'expert', 'max' : 5, 'choices' : ['off', 'default', '2 = id2, 3 = onboard', '2 = onboard, 3 = id2', '2 = onboard, 3 = id3', '2 = onboard, 3 = off'], 'size' : 1, 'adr' : 135, 'column' : 4, 'min' : 0, 'name' : 'Imu3 Configuration', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'Imu3Orientation' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'expert', 'max' : 23, 'choices' : ['no.0 :  z0\u00b0   x  y  z', 'no.1 :  z90\u00b0  -y  x  z', 'no.2 :  z180\u00b0  -x -y  z', 'no.3 :  z270\u00b0   y -x  z', 'no.4 :  x0\u00b0   y  z  x', 'no.5 :  x90\u00b0  -z  y  x', 'no.6 :  x180\u00b0  -y -z  x', 'no.7 :  x270\u00b0   z -y  x', 'no.8 :  y0\u00b0   z  x  y', 'no.9 :  y90\u00b0  -x  z  y', 'no.10 :  y180\u00b0  -z -x  y', 'no.11 :  y270\u00b0   x -z  y', 'no.12 :  -z0\u00b0   y  x -z', 'no.13 :  -z90\u00b0  -x  y -z', 'no.14 :  -z180\u00b0  -y -x -z', 'no.15 :  -z270\u00b0   x -y -z', 'no.16 :  -x0\u00b0   z  y -x', 'no.17 :  -x90\u00b0  -y  z -x', 'no.18 :  -x180\u00b0  -z -y -x', 'no.19 :  -x270\u00b0   y -z -x', 'no.20 :  -y0\u00b0   x  z -y', 'no.21 :  -y90\u00b0  -z  x -y', 'no.22 :  -y180\u00b0  -x -z -y', 'no.23 :  -y270\u00b0   z -x -y'], 'size' : 1, 'adr' : 136, 'min' : 0, 'name' : 'Imu3 Orientation', 'default' : 0, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'Uart1RxConfiguration' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'expert', 'max' : 1, 'choices' : ['off', 'gps target'], 'size' : 1, 'adr' : 139, 'pos' : [4, 5], 'min' : 0, 'name' : 'Uart1 Rx Configuration', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'Uart1TxConfiguration' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'expert', 'max' : 1, 'choices' : ['off', 'oled display'], 'size' : 1, 'adr' : 48, 'min' : 0, 'name' : 'Uart1 Tx Configuration', 'default' : 0, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'MavlinkConfiguration' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'interfaces', 'max' : 3, 'choices' : ['no heartbeat', 'emit heartbeat', 'heartbeat + attitude', 'h.b. + mountstatus'], 'size' : 1, 'adr' : 144, 'min' : 0, 'name' : 'Mavlink Configuration', 'default' : 0, 'foc' : 0, 'unit' : '', 'type' : 'LIST', 'hidden' : 0},
  'MavlinkSystemID' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'interfaces', 'max' : 255, 'size' : 2, 'adr' : 145, 'min' : 0, 'name' : 'Mavlink System ID', 'default' : 71, 'foc' : 0, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'MavlinkComponentID' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'interfaces', 'max' : 255, 'size' : 2, 'adr' : 146, 'min' : 0, 'name' : 'Mavlink Component ID', 'default' : 67, 'foc' : 0, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'UavcanConfiguration' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'interfaces', 'max' : 1, 'choices' : ['off', 'normal'], 'size' : 1, 'adr' : 148, 'pos' : [2, 1], 'min' : 0, 'name' : 'Uavcan Configuration', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'UavcanNodeID' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'interfaces', 'max' : 124, 'size' : 2, 'adr' : 149, 'min' : 11, 'name' : 'Uavcan Node ID', 'default' : 71, 'foc' : 0, 'unit' : '', 'type' : 'UINT', 'hidden' : 0},
  'STorM32LinkConfiguration' : {'len' : 0, 'steps' : 1, 'ppos' : 0, 'page' : 'interfaces', 'max' : 1, 'choices' : ['off', 'normal'], 'size' : 1, 'adr' : 137, 'pos' : [3, 1], 'min' : 0, 'name' : 'STorM32Link Configuration', 'default' : 0, 'foc' : 0, 'unit' : '', 'hidden' : 0, 'type' : 'LIST'},
  'STorM32LinkWaitTime' : {'len' : 0, 'steps' : 5, 'ppos' : 1, 'page' : 'interfaces', 'max' : 250, 'size' : 2, 'adr' : 138, 'min' : 0, 'name' : 'STorM32Link Wait Time', 'default' : 50, 'foc' : 0, 'unit' : 's', 'type' : 'UINT', 'hidden' : 0},
}

var M =
{
  "Dashboard" :             { 'name' : 'Dashboard', 'page' : 'dashboard' },
  "PID" :                   { 'name' : 'PID', 'page' : 'pid' },
  "Pan" :                   { 'name' : 'Pan', 'page' : 'pan' },
  "RcInputs" :              { 'name' : 'Rc Inputs', 'page' : 'rcinputs' },
  "Functions" :             { 'name' : 'Functions', 'page' : 'functions' },
  "Scripts" :               { 'name' : 'Scripts', 'page' : 'scripts' },
  "Setup" :                 { 'name' : 'Setup', 'page' : 'gimbalsetup' },
  "GimbalConfig" :          { 'name' : 'Gimbal Configuration', 'page' : 'gimbalconfig' },
  "Interfaces" :            { 'name' : 'Interfaces', 'page' : 'interfaces' },
  "Expert" :                { 'name' : 'Expert', 'page' : 'expert' },
  "About" :                 { 'name' : 'About', 'page' : 'about' }
}


function getPstrScale(pstr) {
    var scale = 1.0;  
    var ppos = P[pstr].ppos;
    if( ppos==1 ){ scale *= 0.1; }
    if( ppos==2 ){ scale *= 0.01; }
    if( ppos==3 ){ scale *= 0.001; }
    if( ppos==4 ){ scale *= 0.0001; }
    if( ppos==5 ){ scale *= 0.00001; }
    if( ppos==6 ){ scale *= 0.000001; }
    return scale;
}


function do_crc(buf,len) {
    var buffer = new ArrayBuffer(1024);
    var u8View = new Uint8Array(buffer);
    
    for(var i=0;i<len;i++)
        u8View[i] = parseInt(buf.substr(2*i, 2), 16); //fill typed array buffer from the hex stream
    
    var crc = 0xFFFF;
    for(var i=0;i<len;i++){
        var tmp = u8View[i] ^ (crc & 0xFF );
        tmp = (tmp ^ (tmp<<4)) & 0xFF;
        crc = (crc>>8) ^ (tmp<<8) ^ (tmp<<3) ^ (tmp>>4);
        crc = crc & 0xFFFF;
    }
    
    return crc;
}


//-----------------------------------------------------
// onload initialization
//-----------------------------------------------------

window.onload = function ()
{
    PValues = '';
    PStatus = INVALID;  
    XhttpTransferInProgress = false;
    ConnectionIsValid = false;
    GoproIsAvailable = false;

    if( document.getElementById('GoproPage') && (document.getElementById('GoproPage').style.display != 'none') )
        GoproIsAvailable = true;
        
    initMenuHtml();
    initAPageHtml();
    initGoproPageHtml();
    initPPageHtml();

    //document.getElementById('PDebug').style.display = 'block';
    //document.getElementById('xhttp_responseText').style.display = 'none';
    //document.getElementById('xhttp_allResponseHeaders').style.display = 'none';

    var url = document.URL;
    var lastSegment = url.split('/').pop(); //gives the last segment of the url
    updateMenu(null,lastSegment);
    initPBody();
    adaptToFocEnabled();
//    updateRead();

//    document.getElementById('comment').innerText =  "!"+document.body.innerHTML.replace(/</g,'!').replace(/>/g,'!');  
//    document.body.innerHTML =  "<div id='MenuTop' style='display: block; color: #000;  padding: 8px 16px; text-decoration: none;'>!</div>\n"+document.body.innerHTML;  
//    document.body.innerHTML = "<div id='MenuTop'>STorM32 Web App</div>\n" + document.body.innerHTML;  
}


//this are the pages as they also appear in the SETUP_PARAMETERLIST P
// these mirror the first navigation bar (= menu) entries
// it start with the first menu entry, and all menu entries must follow, so that a page also indexes the menu
// the format MUST be as such:
//   "<li><a href='js.html?dashboard' id='MDashboard' onclick='updateMenu(this,\"dashboard\");return false;'>Dashboard</a></li>\n",
// the ?page is used to have a nicier display, but also importantly to figure out the class='active' in the js script
// the last entry is that is also used in SETUP_PARAMTERLIST !!
// js.html is a dummy webpage, for the menu navigation only the ? parameter is used
// this allows to provide a page to cover for the case of an invalid entry
function initMenuHtml() {
    
    var m = "";
    for (var mstr in M) {
       m += "<li><a href='js.html?"+M[mstr].page+"' "+
            "id='M"+mstr+"' onclick='updateMenu(this,\""+M[mstr].page+"\");return false;'>"+M[mstr].name+"</a></li>\n";
    }
    if( GoproIsAvailable )
       m += "<li><a href='js.html?gopro' "+
            "id='MGopro' onclick='updateMenu(this,\"gopro\");return false;'>GoPro Hero5</a></li>\n";
    document.getElementById('NavigationBar').innerHTML = m;
    
//    document.getElementById('comment').innerText = m;
}


function initAPageHtml() {
    
    var c = "";
    
    c += "<input id='FileLoadList' type='button' value='Load File List' onclick='fileLoadList()'/>\n";
//    c += "<input id='FileUpLoadDummy' type='button' value='UpLoad File' onclick='fileUpLoadDummy()'/><input id='FileUpLoad' type='file' onchange='fileUpLoad(event)' style='display:none'/>\n"; //it is crucial to do onchange() and not onclick() here!!
//    c += "<input id='FileDownLoad' type='button' value='DownLoad File' onclick='fileDownLoad()'/>\n";
//    c += "<input id='FileDelete' type='button' value='Delete File' onclick='fileDelete()'/>\n";
    c += "<p></p>\n";
    c += "<div class='FileList'><table id='FileList'>\n<tr><th>file</th><th>size</lt></tr>\n</table></div>\n";  
    c += "<div class='FileInfo'>\n";  
    c += "<div class='FileLabel'><label for='FileFreeValue'>free:</label><span id='FileFreeValue'></span></div>";
    c += "<div class='FileLabel'><label for='FileTotalValue'>max:</label><span id='FileTotalValue'></span></div>\n";
    c += "</div>\n";  
    
    document.getElementById('APage').innerHTML += '<p></p>\n\n'+c+'\n';
    
//    document.getElementById('comment').innerText = c;
}


function initGoproPageHtml() {

    if( !GoproIsAvailable ) return;
    
    var c = "";
    c += "<input id='GoproShutterOn' type='button' value='Shutter On' onclick='updateGoproShutterOn()'/>\n";
    c += "<input id='GoproShutterOff' type='button' value='Shutter Off' onclick='updateGoproShutterOff()'/>\n";
    c += "<p></p>\n";
    c += "<input id='GoproPowerOff' type='button' value='Power Off' onclick='updateGoproPowerOff()'/>\n";
    
    document.getElementById('GoproPage').innerHTML = c;
    
//    document.getElementById('comment').innerText = c;
}



/* the formats must be such:
STR+READONLY:
<p id='FirmwareVersionField' class='PField' style='display:none'><label for='FirmwareVersion' class='PLabel'>Firmware Version</label>
<input id='FirmwareVersion' class='PInput' type='text' value='' readonly/>
</p>\n

LIST:
<p id='GyroLPFField' class='PField' style='display:none'><label for='GyroLPF' class='PLabel'>Gyro LPF</label>
<select id='GyroLPF' class='PSelect' value='0' onchange='updateListA(\"GyroLPF\")'></select>
</p>\n

UINT, INT:
<p id='PitchPField' class='PField' style='display:none'><label for='PitchP' class='PLabel'>Pitch P</label>
<input id='PitchP' class='PInput' type='number' value='0' onchange='updateUI(\"PitchP\")'/>
<input id='PitchPSlider' class='PSlider' type='range' value='0' onchange='updateUISlider(\"PitchP\")' oninput='updateUISlider(\"PitchP\")'/>
</p>\n
*/
function initPPageHtml() {
    
    var c = "";
    c += "<input id='read' class='read' type='button' value='Read' onclick='updateRead()'/>\n";
    c += "<input id='write' class='write' type='button' value='Write' onclick='updateWrite()'/>\n";
    c += "<input id='storecheck' type='checkbox' name='storecheck' value='dostore' onclick='updateStoreCheck()'/>";
    c += "<p></p>\n";
    document.getElementById('PCmdLine').innerHTML = c;
    
    var p = "";
    for (var pstr in P) {
        switch(P[pstr].type){
        case 'STR+READONLY':
            p += "<p id='"+pstr+"Field' class='PField' style='display:none'>"+
                 "<label for='"+pstr+"' class='PLabel'>"+P[pstr].name+"</label>"+
                 "<input id='"+pstr+"' class='PInput' type='text' value='' readonly/></p>\n";
            break;
        case 'LIST':    
            p += "<p id='"+pstr+"Field' class='PField' style='display:none'>"+
                 "<label for='"+pstr+"' class='PLabel'>"+P[pstr].name+"</label>"+
                 "<select id='"+pstr+"' class='PSelect' value='0' onchange='updateListA(\""+pstr+"\")'></select></p>\n";
            break;
        case 'UINT': case 'INT':    
            p += "<p id='"+pstr+"Field' class='PField' style='display:none'>"+
                 "<label for='"+pstr+"' class='PLabel'>"+P[pstr].name+"</label>"+
                 "<input id='"+pstr+"' class='PInput' type='number' value='0' onchange='updateUI(\""+pstr+"\")'/>"+
                 "<input id='"+pstr+"Slider' class='PSlider' type='range' value='0' "+
                    "onchange='updateUISlider(\""+pstr+"P\")' oninput='updateUISlider(\""+pstr+"\")'/></p>\n";
            break;
        }
    }
    
    p += "<div id='PDashboardFooter' class='PDashboardFooter'></div>\n";
    
    document.getElementById('PBody').innerHTML = p;    
    
//    document.getElementById('comment').innerText = p;
}

 
function initPBodyListA(pstr) {
    var Elem = document.getElementById(pstr);    

    var html = "";
    for(var i=0; i<P[pstr].choices.length; i++){
        if( i == parseInt(Elem.value) ) {
            html += "<option value='"+i+"' selected>"+P[pstr].choices[i]+"</option>\n";        
        }else{
            html += "<option value='"+i+"'>"+P[pstr].choices[i]+"</option>\n";
        }
    }

    Elem.innerHTML =  html;

    Elem.min = 0;
    Elem.max = parseInt(P[pstr].max); //for a ListA it's an integer
    Elem.value = parseInt(P[pstr].default);
    
//    document.getElementById('comment').innerText = 'initPBodyListA ' + html;
}


function initPBodyUI(pstr) {
    var Elem = document.getElementById(pstr);    

    var scale = getPstrScale(pstr);
  
    var Xmin = parseFloat(P[pstr].min) * scale;
    var Xmax = parseFloat(P[pstr].max) * scale;
    var Xdefault = parseFloat(P[pstr].default) * scale;
    var Xstep = parseFloat(P[pstr].steps) * scale;
  
    Elem.min = Xmin;
    Elem.max = Xmax;
    Elem.step = Xstep;
    Elem.value = Xdefault;
  
    var ElemSlider = document.getElementById(pstr+'Slider');
  
    ElemSlider.min = Xmin; //the order is important, do default last
    ElemSlider.max = Xmax;
    ElemSlider.step = Xstep;
    ElemSlider.value = Xdefault;
  
//    document.getElementById('comment').innerText = 'initPBodyUI ' + Xmin + ',' + Xmax + ',' + Xstep + ',' + scale;
}


function initPDashboardFooter() {
    var c = ''; //'<p></p>\n';
    c += "<div class='DInfo'><span class='DInfoTitle'>Info Center:</span>";
    c += "<div class='DInfoTable'><table>\n";
    c += "<tr><td><label>Imu1</label><span id='DInfoImu1'> -<\span></td><td><label>State</label><span id='DInfoState'> -<\span></td></tr>\n";    
    c += "<tr><td><label>Imu2</label><span id='DInfoImu2'> -<\span></td><td><label>Voltage</label><span id='DInfoVoltage'> -<\span></td></tr>\n";    
    c += "<tr><td><label>Encoders</label><span id='DInfoEncoders'> -<\span></td><td><label>Imu1:</label><span id='DInfoImu1State'> -<\span></td></tr>\n";    
    c += "<tr><td><label>Bat</label><span id='DInfoBat'> -<\span></td><td><label>Imu2:</label><span id='DInfoImu2State'> -<\span></td></tr>\n";    
    c += "<tr><td><label>Motors</label><span id='DInfoMotors'> -<\span></td><td><label>Encoders:</label><span id='DInfoEncodersState'> - - -<\span></td></tr>\n";    
    c += "<tr><td></td><td><label>Bus Errors:</label><span id='DInfoBusErrors'> -<\span></td></tr>\n";    
    c += "</div></table></div>\n";
    
//    document.getElementById('comment').innerText = '\n'+c;
    
    document.getElementById('PDashboardFooter').innerHTML = c;
}


function initPBody() {
    for (var pstr in P) {
        if( !document.getElementById(pstr) ) continue;
        if( P[pstr].type == 'LIST' ) initPBodyListA(pstr);
        if( P[pstr].type == 'UINT' ) initPBodyUI(pstr);
        if( P[pstr].type == 'INT' ) initPBodyUI(pstr);
        if( P[pstr].type == 'STR+READONLY' ) document.getElementById(pstr).value = '';
    }
    
    initPDashboardFooter();
    
    setPAllToInvalid();
    
//    document.getElementById('comment').innerText = 'initPBody';
}


//-----------------------------------------------------
// PBody adaption handling
//-----------------------------------------------------

var BoardConfiguration_FOC_DisabledParameters = [
  'Imu2 FeedForward LPF', 'Voltage Correction',
  'Imu2 Configuration', 'Startup Mode',
  'Motor Mapping'
];
var BoardConfiguration_FOC_HidedParameters = [
  'Gyro LPF',
  'Pitch P', 'Pitch I', 'Pitch D', 'Pitch Motor Vmax',
  'Roll P', 'Roll I', 'Roll D', 'Roll Motor Vmax',
  'Yaw P', 'Yaw I', 'Yaw D', 'Yaw Motor Vmax',
  'Pitch Motor Poles', 'Pitch Motor Direction', 'Pitch Startup Motor Pos',
  'Roll Motor Poles', 'Roll Motor Direction', 'Roll Startup Motor Pos',
  'Yaw Motor Poles', 'Yaw Motor Direction', 'Yaw Startup Motor Pos',
];
var BoardConfiguration_FOC_ShownParameters = [
  'Foc Gyro LPF',
  'Foc Pitch P', 'Foc Pitch I', 'Foc Pitch D', 'Foc Pitch K',
  'Foc Roll P', 'Foc Roll I', 'Foc Roll D', 'Foc Roll K',
  'Foc Yaw P', 'Foc Yaw I', 'Foc Yaw D', 'Foc Yaw K',
  'Foc Pitch Motor Direction', 'Foc Pitch Zero Pos',
  'Foc Roll Motor Direction', 'Foc Roll Zero Pos',
  'Foc Yaw Motor Direction', 'Foc Yaw Zero Pos',
];

function arrayContains(array,element)
{
    for(var i=0; i<array.length; i++){ if( array[i] == element ) return true; } //=== type correct comparison
    return false;
}


function i_updateAPage() {
    
}


function i_updateGoproPage() {
    
}

        
// mstr must be lower case
function i_updatePPage(mstr) {
    if( mstr === 'gimbalsetup' ) mstr = 'setup'; //this is needed since the page name for Setup is different in P and in M
    for (var pstr in P) {
        if( !document.getElementById(pstr) ) continue;
        var disp = 'none';
      
        if( P[pstr].page == mstr ){
            var isFocParam = false;
            if( pstr.match(/Foc/) ) isFocParam = true;
            if( FocIsEnabled ){
                if( arrayContains(BoardConfiguration_FOC_DisabledParameters,P[pstr].name) ){
                     //show disabled //doesn't make sense here since we do not have a grid format of the param fields
                    //disp = 'block'; enable = false;
                }else
                if( arrayContains(BoardConfiguration_FOC_HidedParameters,P[pstr].name) ){
                    //hide
                }else
                if( arrayContains(BoardConfiguration_FOC_ShownParameters,P[pstr].name) ){
                    disp = 'block';
                }else{
                    disp = 'block';
                }
            }else{
                if( !isFocParam ) disp = 'block';
            }
               
        }
          
        document.getElementById(pstr+'Field').style.display = disp;
    }
}


//-----------------------------------------------------
// menu handling
//-----------------------------------------------------

function updateMenu(caller,mstr) {
    mstr = mstr.toLowerCase();
//    document.getElementById('comment').innerText = 'updateMenu '+mstr;  
    document.getElementById('IsLoading').style.display = 'none';
    if( mstr == '' ) mstr = 'dashboard';

    // do the navigation bar
    var lis = document.getElementById('NavigationBar').querySelectorAll('a');
    for(var i=0; i<lis.length; i++){
        var m = lis[i].href.split('?').pop(); 
        if( mstr == m ){ lis[i].classList.add('active'); }else{ lis[i].classList.remove('active'); }
        
//        document.getElementById('comment').innerText += '\n'+i+','+mstr+','+m;
    }  
    
    if( mstr == 'about' ){ //APage
        document.getElementById('APage').style.display = 'block';
        document.getElementById('GoproPage').style.display = 'none';
        document.getElementById('PPage').style.display = 'none';
        i_updateAPage();
    }else
    if( (mstr == 'gopro') && GoproIsAvailable ){ //GoproPage
        document.getElementById('APage').style.display = 'none';
        document.getElementById('GoproPage').style.display = 'block';
        document.getElementById('PPage').style.display = 'none';
        i_updateGoproPage();
    }else{ //Parameter page  
        document.getElementById('APage').style.display = 'none';
        document.getElementById('GoproPage').style.display = 'none';
        document.getElementById('PPage').style.display = 'block';
        i_updatePPage(mstr);

        if( mstr == 'dashboard' )
            document.getElementById('PDashboardFooter').style.display = 'block';
        else
            document.getElementById('PDashboardFooter').style.display = 'none';            
    }        
  
    window.scrollTo(0, 0);
    
    return false;
}


//-----------------------------------------------------
// store checkbox handling
//-----------------------------------------------------

function updateStoreCheck() {
    
    if( document.getElementById('storecheck').checked ){
        document.getElementById('write').value = 'Write+Store';
    }else{
        document.getElementById('write').value = 'Write';
    }
}


function setStoreUnchecked() {
    document.getElementById('storecheck').checked = false;
    document.getElementById('write').value = 'Write';
}


function isStoreChecked() {
    return document.getElementById('storecheck').checked;
}


//-----------------------------------------------------
// color handling
//-----------------------------------------------------

function setPColor(pstr,color) {
    var Elem = document.getElementById(pstr);
    if( !Elem ) return;
    Elem.style.backgroundColor = color;
}

function setPToInvalid(pstr){
    setPColor(pstr, '#FFbbbb'); //'red');
    PStatus = INVALID;
}

function setPToValid(pstr) {
    setPColor(pstr, '#bbFFbb'); //'lightgreen');
    PStatus = VALID;
}

function setPToModified(pstr) {
    setPColor(pstr, '#bbbbFF'); //'lightblue');
    PStatus = MODIFIED;
}

function setPAllToInvalid() {
    PValues = '';
    for (var pstr in P) { setPToInvalid(pstr);  }
    clearStatus();
}

function setPAllToValid() {
    for (var pstr in P) { setPToValid(pstr); }
}


//-----------------------------------------------------
// element update handling
//-----------------------------------------------------

function updateListA(pstr) {
    document.getElementById('comment').innerHTML = 'update'+pstr;
    
    setPToModified(pstr);
}


function parsePFloat(pstr,ppos) {
    var Elem = document.getElementById(pstr);
    var val = parseFloat(Elem.value);
    var min = parseFloat(Elem.min); //can't use P[pstr]. since pstr may have a 'Slider'
    var max = parseFloat(Elem.max); 
    var step = parseFloat(Elem.step); 
    if( val < min ){ val = min; }
    if( val > max ){ val = max; }
    //TODO we here also need to respect the step!!!!

//    document.getElementById('comment').innerHTML='parsePFloat '+pstr+','+ppos+','+min+','+max+','+step+','+val;

    return (val).toFixed(ppos);
}


function updateUI(pstr) {
    document.getElementById('comment').innerHTML = 'update'+pstr;
    var val = parsePFloat(pstr, P[pstr].ppos);
    document.getElementById(pstr).value = val;
    document.getElementById(pstr+'Slider').value = val;
    
    setPToModified(pstr);
}


function updateUISlider(pstr) {
    document.getElementById('comment').innerHTML = 'update'+pstr+'Slider';
    var val = parsePFloat(pstr+'Slider', P[pstr].ppos);
    document.getElementById(pstr).value = val;
    document.getElementById(pstr+'Slider').value = val;
    
    setPToModified(pstr);
}
 

//-----------------------------------------------------
// AJAX
//-----------------------------------------------------

//https://stackoverflow.com/questions/13697829/hexadecimal-to-string-in-javascript
function hex2a(hex) {
    var str = '';
    for (var i = 0; i < hex.length; i += 2) {
        var v = parseInt(hex.substr(i, 2), 16);
        if (v) str += String.fromCharCode(v); //this skips any '\0'
    }
    return str;
} 

//converts a hex XXXX to a u16, taking into account having to swap
function hex2u16(hex) {
    return  parseInt( hex.substr(2,2)+hex.substr(0,2), 16);
} 

//swaps AABB to BBAA
function hexswap(hex) {
    return  hex.substr(2,2)+hex.substr(0,2);
} 

//converts a value into hex XXXX
function a2hex(a) {
    var hex = a.toString(16).toUpperCase();
    while( hex.length < 4 ) hex = '0'+hex;
    return hex;
}  


//converts a u16 into a hex XXXX, taking into account having to swap
function u162hex(a) {
    var hex = a2hex(a);
    return hex.substr(2,2)+hex.substr(0,2);
}    


function setPValueLISTA(pstr,hex) {
    var value = parseInt(hex,16);
    document.getElementById(pstr).value = value;
    setPToValid(pstr);
}    

function setPValueUI(pstr,hex) {
    var scale = getPstrScale(pstr);
    var value = ( parseFloat(parseInt(hex,16)) * scale ).toFixed(P[pstr].ppos);
    document.getElementById(pstr).value = value;
    document.getElementById(pstr+'Slider').value = value;
    setPToValid(pstr);
}    

function setPValueSI(pstr,hex) {
    var scale = getPstrScale(pstr);
    var i = parseInt(hex,16);
    if( i > 32767 ) i -= 65536;
    var value = ( parseFloat(i) * scale ).toFixed(P[pstr].ppos);
    document.getElementById(pstr).value = value;
    document.getElementById(pstr+'Slider').value = value;
    setPToValid(pstr);
}



function adaptToFocEnabled()
{
    //adapt title
    if( FocIsEnabled ){
        document.getElementById('AppConfiguration').innerHTML = " -  for T-STorM32";
    }else{
        document.getElementById('AppConfiguration').innerHTML = " -  for STorM32-NT";
    }
    
    //find active menu
    var mstr = '?';
    var lis = document.getElementById('NavigationBar').querySelectorAll('a');
    for(var i=0; i<lis.length; i++){
        if( lis[i].classList.contains('active') ){ mstr = lis[i].href.split('?').pop(); }
    }  

    //update PBody
    i_updatePPage(mstr);
}


function updateFocEnabled(capabilities)
{
    //check if capability has changed
    var hasFocCapability = false;
    if( capabilities & BOARD_CAPABILITY_FOC ) hasFocCapability = true;
    if( hasFocCapability == FocIsEnabled ) return;
    FocIsEnabled = hasFocCapability;
    
    adaptToFocEnabled();
}


function updateRead()
{
    document.getElementById('comment').innerHTML = 'Read clicked... ';
    document.getElementById('xhttp_responseText').innerHTML = '';
    document.getElementById('xhttp_allResponseHeaders').innerHTML = '';
    ajaxPost('read?p=all', '', function(xhttp){ // ?p=all is ignored currently
        var com = '';
        var args = xhttp.responseText.split(','); //the reponse comes formatted as "v=XX...XX,p=XX...XX,"
        if( (xhttp.responseText.substr(0,1) != 'v')  || (args.length < 2) ){
            ConnectionIsValid = false;
            setPAllToInvalid();
            com = 'failed';
            alert("Read failed, no connection to STorM32.");
        }else{
            var v = args[0].substr(2);
            var firmware = hex2a(v.substr(0,16*2));
            var board = hex2a(v.substr(16*2,16*2));
            var name = hex2a(v.substr(32*2,16*2));
            var version = hex2u16(v.substr(48*2,2*2));
            var layout = hex2u16(v.substr(50*2,2*2));
            var capabilities = hex2u16(v.substr(52*2,2*2));
        
            updateFocEnabled(capabilities);

            document.getElementById('FirmwareVersion').value = firmware;
            document.getElementById('Board').value = board;
            document.getElementById('Name').value = name;
        
            var g = args[1].substr(2);
            for (var pstr in P) {
                if( !document.getElementById(pstr) ) continue;
                switch( P[pstr].type ){
                    case 'LIST':
                        var adr = P[pstr].adr;
                        var hex = g.substr(4*adr+2,2)+g.substr(4*adr,2);
                        setPValueLISTA(pstr,hex);
                        break;
                    case 'UINT':
                        var adr = P[pstr].adr;
                        var hex = g.substr(4*adr+2,2)+g.substr(4*adr,2);
                        setPValueUI(pstr,hex);
                        break;
                    case 'INT':
                        var adr = P[pstr].adr;
                        var hex = g.substr(4*adr+2,2)+g.substr(4*adr,2);
                        setPValueSI(pstr,hex);
                        break;
                    case 'STR+READONLY':
                        setPToValid(pstr);
                        break;                
                    default:
                        setPToInvalid(pstr);
                }
            }
            PValues = g;
            PStatus = VALID; //this overrides it
            
            //the connection is valid, so we can trigger updating the status
            updateStatus(); 
        
            com = 'ok' + ','+version+','+layout+','+capabilities+'(x'+a2hex(capabilities)+')'+','+FocIsEnabled;
        }        

        document.getElementById('comment').innerHTML += com;
        document.getElementById('xhttp_responseText').innerHTML = xhttp.responseText;
        document.getElementById('xhttp_allResponseHeaders').innerHTML = xhttp.getAllResponseHeaders();
    });
}



function getPValueLISTA(pstr) {
    var value = parseInt(document.getElementById(pstr).value);
    
    setPToValid(pstr);
    return a2hex(value);
}    

function getPValueUI(pstr) {
    var scale = getPstrScale(pstr);
    var value = parseFloat(document.getElementById(pstr).value);
    value = parseInt(Math.round(value / scale));
    if( value < 0 ) value += 65536;
    
    setPToValid(pstr);
    return a2hex(value);
}    

function getPValueSI(pstr) {
    var scale = getPstrScale(pstr);
    var value = parseFloat(document.getElementById(pstr).value);
    value = parseInt(Math.round(value / scale));
    if( value < 0 ) value += 65536;
    
    setPToValid(pstr);
    return a2hex(value);
}    


function setPArray(pa,adr,hex) {
    pa[4*adr] = hex.substr(2,1);
    pa[4*adr+1] = hex.substr(3,1);
    pa[4*adr+2] = hex.substr(0,1);
    pa[4*adr+3] = hex.substr(1,1);
}


function updateWrite()
{
    document.getElementById('comment').innerHTML = 'Write clicked... ';
    document.getElementById('xhttp_responseText').innerHTML = '';
    document.getElementById('xhttp_allResponseHeaders').innerHTML = '';
    
    if( !ConnectionIsValid || (PStatus == INVALID) ){
        document.getElementById('comment').innerHTML += ', no read was done before, hence aborted';
        return;
    }
   
    //take PValues without last 'o' as template, overwrite with those in the Inputs
    var p = PValues.slice(0,-2-4); //remove the last 'o' = '6F' (i.e. two chars) //also remove the crc
    var pa = p.split(''); // array of characters, better to work with than a string
    
    var pp = ''; // this is just for a pretty debug output
    var pa_pretty = pa.slice(); // this is just for a pretty debug output //don't do pa_pretty = p, as this just copies the reference
        
    for (var pstr in P) {
        if( !document.getElementById(pstr) ) continue;
        switch( P[pstr].type ){
            case 'LIST':
                var adr = P[pstr].adr;
                var hex = getPValueLISTA(pstr);
                setPArray(pa, adr, hex);
                
                pp += hex + '('+ parseInt(adr) + '=' + parseInt(hex,16) +'),';
                setPArray(pa_pretty, adr, hex);
                pa_pretty[4*adr] = '<span style="color:red">'+pa_pretty[4*adr]; pa_pretty[4*adr+3] += '</span>';
                break;
            case 'UINT':
                var adr = P[pstr].adr;
                var hex = getPValueUI(pstr);
                setPArray(pa, adr, hex);

                pp += hex + '('+ parseInt(adr) + '=' + parseInt(hex,16) +'),';
                setPArray(pa_pretty, adr, hex);
                pa_pretty[4*adr] = '<span style="color:red">'+pa_pretty[4*adr]; pa_pretty[4*adr+3] += '</span>';
                break;
            case 'INT':
                var adr = P[pstr].adr;
                var hex = getPValueSI(pstr);
                setPArray(pa, adr, hex);

                pp += hex + '('+ parseInt(adr) + '=' + parseInt(hex,16) +'),';
                setPArray(pa_pretty, adr, hex);
                pa_pretty[4*adr] = '<span style="color:red">'+pa_pretty[4*adr]; pa_pretty[4*adr+3] += '</span>';
                break;
            case 'STR+READONLY': //skip
                break;                
            default: //skip
        }
    }

    p = pa.join(''); //combine it back to a string
    
    var hexcrc = u162hex( do_crc(p, p.length/2) );
    p += hexcrc;
    
    document.getElementById('comment').innerHTML += 'ok' + ',' + hexcrc;//'ok\n' + PValues + '\n' + pa_pretty.join('') + ',' + hexcrc;
    
    var cmd = 'write?p=all';
    if( isStoreChecked() ) cmd = 'write?s=y&p=all';
    
    ConnectionIsValid = true; //set it here, so it can be reset by the xhhtp request
    
    ajaxPost(cmd, p, function(xhttp){ // ?p=all is ignored currently
        document.getElementById('xhttp_responseText').innerHTML = xhttp.responseText;
        document.getElementById('xhttp_allResponseHeaders').innerHTML = xhttp.getAllResponseHeaders();
    });
    
    //TODO: we need here to check if the write was successfull!!!
    // both ConnectionIsValid and 'o' must be checked
    
    setPAllToValid();  
    setStoreUnchecked();
}


//-----------------------------------------------------
// status and Info Pane handling
//-----------------------------------------------------

function getStorm32State(state) {
    switch( state ){
        case 0: return 'STARTUP_MOTORS';
        case 1: return 'SETTLE';
        case 2: return 'CALIBRATE';
        case 3: return 'LEVEL';
        case 4: return 'MOTORDIRDETECT';
        case 5: return 'RELEVEL';
        case 6: return 'NORMAL';
        case 7: return 'FASTLEVEL';
        case 32: return 'WAITFORSTORM32LINK';
        case 99: return 'STANDBY';
        case 100: return 'QMODE';
    }
    return 'unknown';
}    

//status flags
var STATUS_IMU_PRESENT =              0x8000; //is checked at start
var STATUS_IMU2_PRESENT =             0x1000; //is checked at start
var STATUS_IMU2_HIGHADR =             0x0800; //is set at start
var STATUS_IMU2_NTBUS =               0x0400; //is set at start

var STATUS_BAT_VOLTAGEISLOW =         0x0010;
var STATUS_BAT_ISCONNECTED =          0x0008; //is set as soon as V>5.5V is detected first time after start
var STATUS_LEVEL_FAILED =             0x0004;

var STATUS_IMU_OK =                   0x0020;
var STATUS_IMU2_OK =                  0x0040;

//status2 flags
var STATUS2_ENCODERS_PRESENT =        0x8000;
var STATUS2_ENCODERYAW_OK =           0x4000;
var STATUS2_ENCODERROLL_OK =          0x2000;
var STATUS2_ENCODERPITCH_OK =         0x1000;

var STATUS2_MOTORYAW_ACTIVE =         0x0020; //sequence is important, must mirror MOTORPITCHENABLED etc., is used by GUI
var STATUS2_MOTORROLL_ACTIVE =        0x0010;
var STATUS2_MOTORPITCH_ACTIVE =       0x0008;


function clearStatus()
{
    document.getElementById('DInfoImu1').innerHTML = '-';
    document.getElementById('DInfoImu1State').innerHTML = '-';
    document.getElementById('DInfoImu2').innerHTML = '-';
    document.getElementById('DInfoImu2State').innerHTML = '-';
    document.getElementById('DInfoEncoders').innerHTML = '-';
    document.getElementById('DInfoEncodersState').innerHTML = '- - -';
    document.getElementById('DInfoMotors').innerHTML = '-';
    document.getElementById('DInfoState').innerHTML = '-';
    document.getElementById('DInfoBat').innerText = '-';
    document.getElementById('DInfoVoltage').innerText = '-';
    document.getElementById('DInfoBusErrors').innerText = '-';
}


function updateStatus()
{
    if( !ConnectionIsValid ) return;
    
    //document.getElementById('comment').innerHTML = 'Status clicked... ';
    //document.getElementById('xhttp_responseText').innerHTML = '';
    //document.getElementById('xhttp_allResponseHeaders').innerHTML = '';
    ajaxPost('exec?cmd=s', '', function(xhttp){
        var com = '';
        var args = xhttp.responseText; //the reponse comes formatted as "s=XX...XX,"
        if( xhttp.responseText.substr(0,1) != 's' ){
            ConnectionIsValid = false;
            setPAllToInvalid();
            com = 'failed';
        }else{
            var v = args.substr(2); //strip of the 's='
            var state = hex2u16(v.substr(0,2*2));
            var status = hex2u16(v.substr(2*2,2*2));
            var status2 = hex2u16(v.substr(4*2,2*2));
            var status3 = hex2u16(v.substr(6*2,2*2));
            var performance = hex2u16(v.substr(8*2,2*2));
            var errors = hex2u16(v.substr(10*2,2*2));
            var voltage = hex2u16(v.substr(12*2,2*2));
                        
            var c = ''; var c2 = '';

            if( status & STATUS_IMU_PRESENT ){
                c = ' is PRESENT'; c += ' @ NtBus';
                if( status & STATUS_IMU_OK ) c2 = ' OK'; else c2 = ' ERR';
            }else{ 
                c = ' is not available'; c2 = ' -';
            }
            document.getElementById('DInfoImu1').innerHTML = c;
            document.getElementById('DInfoImu1State').innerHTML = c2;
            
            if( status & STATUS_IMU2_PRESENT ){
                c = ' is PRESENT'; 
                if( status & STATUS_IMU2_NTBUS ){ 
                    c += ' @ NtBus';
                }else{
                    if( status & STATUS_IMU2_HIGHADR ){ c+= ' @ high adr = on-board Imu'; }else{ c += ' @ low adr = external Imu'; }
                }
                if( status & STATUS_IMU2_OK ) c2 = ' OK'; else c2 = ' ERR';
            }else{ 
                c = ' is not available'; c2 = ' -';
            }
            document.getElementById('DInfoImu2').innerHTML = c;
            document.getElementById('DInfoImu2State').innerHTML = c2;

            if( status2 & STATUS2_ENCODERS_PRESENT ) c = ' are PRESENT'; else c = ' are not available';
            document.getElementById('DInfoEncoders').innerHTML = c;
            c = '';
            if( status2 & STATUS2_ENCODERS_PRESENT ){
                if( status2 & STATUS2_ENCODERPITCH_OK ) c += ' OK'; else c += ' ERR';
                if( status2 & STATUS2_ENCODERROLL_OK ) c += ' OK'; else c += ' ERR';
                if( status2 & STATUS2_ENCODERYAW_OK ) c += ' OK'; else c += ' ERR';
            }else c += ' - - -'; 
            document.getElementById('DInfoEncodersState').innerHTML = c;
 
            c = ' are';
            if( status2 & STATUS2_MOTORPITCH_ACTIVE ) c += ' ACTIVE'; else c += ' OFF';
            if( status2 & STATUS2_MOTORROLL_ACTIVE ) c += ' ACTIVE'; else c += ' OFF';
            if( status2 & STATUS2_MOTORYAW_ACTIVE ) c += ' ACTIVE'; else c += ' OFF'; 
            document.getElementById('DInfoMotors').innerHTML = c;
                        
            document.getElementById('DInfoState').innerHTML = ' is ' + getStorm32State(state);
            
            if( status & STATUS_BAT_ISCONNECTED ) c = ' is CONNECTED'; else c = ' is not connected';
            document.getElementById('DInfoBat').innerText = c;
            if( status & STATUS_BAT_VOLTAGEISLOW ) c = ' is LOW: '; else c = ' is OK: ';
            document.getElementById('DInfoVoltage').innerText = c + parseFloat(voltage*0.001).toFixed(2)+' V';
           
            document.getElementById('DInfoBusErrors').innerText = parseInt(errors);
       
            com = 'ok';
            
            //connection is valid, so trigger a next time
            setTimeout(updateStatus, 1000);
        }

        //document.getElementById('comment').innerHTML += com;
        //document.getElementById('xhttp_responseText').innerHTML = xhttp.responseText;
        //document.getElementById('xhttp_allResponseHeaders').innerHTML = xhttp.getAllResponseHeaders();
    });
}



//-----------------------------------------------------
// file handling
//-----------------------------------------------------

function fileLoadList() {
    document.getElementById('comment').innerHTML = 'Load File List clicked... ';
    document.getElementById('xhttp_responseText').innerHTML = '';
    document.getElementById('xhttp_allResponseHeaders').innerHTML = '';

    ajaxPost('fslist?dir=/', 'TEST', function(xhttp){
        //json format { "files" : [ { "name" : "xxxxxx.xxx", "size" : "xxx" } , {} .... ], "total" : "bytes", "free" : "bytes" }
        var c = 'Error in json parse';
        {try{ 
            var Fjson = JSON.parse(xhttp.responseText); 
            c = "<tr><th>file</th><th>size</th></tr>\n";
            for(var i=0; i<Fjson.files.length;i++) {
                c += "<tr><td>"+Fjson.files[i].name+"</td><td>"+Fjson.files[i].size+"</td></tr>\n";
            }
            document.getElementById('FileList').innerHTML = c;
            document.getElementById('FileTotalValue').innerHTML = Fjson.total;
            document.getElementById('FileFreeValue').innerHTML = Fjson.free;
        }catch(e){}}
        
//        document.getElementById('comment').innerText += '\n' + c;
        document.getElementById('xhttp_responseText').innerHTML = xhttp.responseText;
        document.getElementById('xhttp_allResponseHeaders').innerHTML = xhttp.getAllResponseHeaders();
    });
}


function fileUpLoadDummy() {
    document.getElementById('FileUpLoad').click();
}

// https://wiki.selfhtml.org/wiki/JavaScript/File_Upload
function fileUpLoad(evt) {
    document.getElementById('comment').innerHTML = 'UpLoad File clicked... ';
    document.getElementById('xhttp_responseText').innerHTML = '';
    document.getElementById('xhttp_allResponseHeaders').innerHTML = '';

    var files = evt.target.files; // FileList object
//    document.getElementById('comment').innerText += '\n' + files + '!' + files.length;
//	for (var i=0; i<files.length; i++) {
//        document.getElementById('comment').innerText += '\n' + files[i].name + '!';
// 	}
    if( !files.length ) return;
    
    var filename = files[0].name;
    document.getElementById('comment').innerText += '\n selected file is ' + filename;
  
    
    
/*
    ajaxPost('fslist?dir=/', 'TEST', function(xhttp){ // ?dir=/ is ignored currently
        //json format [ { "type" : "file" ,"name" : "xxxxxx.xxx", "size" : "xx" } , {} .... ]
        var Fjson = JSON.parse(xhttp.responseText); 
        
        var c = "<tr><th>file</th><th>size</th></tr>\n";
        for(var i=0; i<Fjson.length;i++) {
            c += "<tr><td>"+Fjson[i].name+"</td><td>"+Fjson[i].size+"</td></tr>\n";
        }
        document.getElementById('FileList').innerHTML = c;
        
        document.getElementById('comment').innerText += '\n' + c;
        document.getElementById('xhttp_responseText').innerHTML = xhttp.responseText;
        document.getElementById('xhttp_allResponseHeaders').innerHTML = xhttp.getAllResponseHeaders();
    });
*/    
}


function fileDownLoad(evt) {
    document.getElementById('comment').innerHTML = 'DownLoad File clicked... ';
    document.getElementById('xhttp_responseText').innerHTML = '';
    document.getElementById('xhttp_allResponseHeaders').innerHTML = '';
}


function fileDelete() {
    document.getElementById('comment').innerHTML = 'Delete File clicked... ';
    document.getElementById('xhttp_responseText').innerHTML = '';
    document.getElementById('xhttp_allResponseHeaders').innerHTML = '';
}








//-----------------------------------------------------
// GoPro handling
//-----------------------------------------------------
//we don't need to check for GoproIsAvailable here
// the commands are supported, they will return an 'e' if no Gopro is connected 

function updateGoproShutterOn()
{
    document.getElementById('comment').innerHTML = 'Shutter On clicked';
    document.getElementById('xhttp_responseText').innerHTML = '';
    document.getElementById('xhttp_allResponseHeaders').innerHTML = '';

    ajaxPost('gps1', '', function(xhttp){
        document.getElementById('xhttp_responseText').innerHTML = xhttp.responseText;
        document.getElementById('xhttp_allResponseHeaders').innerHTML = xhttp.getAllResponseHeaders();
        
        if( xhttp.responseText == 'e' ) alert("No connection to Gopro.");
    });
}

function updateGoproShutterOff()
{
    document.getElementById('comment').innerHTML = 'Shutter Off clicked';
    document.getElementById('xhttp_responseText').innerHTML = '';
    document.getElementById('xhttp_allResponseHeaders').innerHTML = '';

    ajaxPost('gps0', '', function(xhttp){
        document.getElementById('xhttp_responseText').innerHTML = xhttp.responseText;
        document.getElementById('xhttp_allResponseHeaders').innerHTML = xhttp.getAllResponseHeaders();
        
        if( xhttp.responseText == 'e' ) alert("No connection to Gopro.");
    });
}

function updateGoproPowerOff()
{
    document.getElementById('comment').innerHTML = 'Power Off clicked';
    document.getElementById('xhttp_responseText').innerHTML = '';
    document.getElementById('xhttp_allResponseHeaders').innerHTML = '';

    ajaxPost('gpp0', '', function(xhttp){
        document.getElementById('xhttp_responseText').innerHTML = xhttp.responseText;
        document.getElementById('xhttp_allResponseHeaders').innerHTML = xhttp.getAllResponseHeaders();
        
        if( xhttp.responseText == 'e' ) alert("No connection to Gopro.");
    });
}
