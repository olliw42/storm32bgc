﻿# My GoPro Hero Stuff

## LICENCE

GPL v3

## ACKNOWLEDGMENTS

https://github.com/KonradIT/goprowifihack