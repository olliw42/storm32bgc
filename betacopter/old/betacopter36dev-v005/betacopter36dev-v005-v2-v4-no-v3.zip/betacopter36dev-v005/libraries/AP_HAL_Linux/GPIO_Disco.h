#pragma once

#include "GPIO_Sysfs.h"

enum gpio_disco {
    DISCO_GPIO_MPU6050_DRDY,
    LINUX_GPIO_ULTRASOUND_VOLTAGE,
    _DISCO_GPIO_MAX,
};
