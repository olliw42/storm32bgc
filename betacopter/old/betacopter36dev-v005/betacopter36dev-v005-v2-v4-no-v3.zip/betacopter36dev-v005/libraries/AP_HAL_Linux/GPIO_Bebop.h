#pragma once

#include "GPIO_Sysfs.h"

enum gpio_bebop {
    BEBOP_GPIO_CAMV_NRST,
    LINUX_GPIO_ULTRASOUND_VOLTAGE,
    _BEBOP_GPIO_MAX,
};
